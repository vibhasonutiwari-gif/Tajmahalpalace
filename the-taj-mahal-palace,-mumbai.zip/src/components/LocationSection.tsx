import React from 'react';
import { HOTEL_INFO } from '../data/hotelData';
import { MapPin, Phone, MessageCircle, Navigation, Star, Clock, Compass } from 'lucide-react';

export const LocationSection: React.FC = () => {
  const whatsappUrl = `https://wa.me/${HOTEL_INFO.phoneClean}?text=Hello%20Taj%20Concierge%2C%20I%20would%20like%20to%20inquire%20about%20a%20luxury%20reservation%20at%20The%20Taj%20Mahal%20Palace%2C%20Mumbai.`;
  const directionsUrl = `https://www.google.com/maps/dir/?api=1&destination=The+Taj+Mahal+Palace+Apollo+Bunder+Colaba+Mumbai+400001`;

  return (
    <section id="location" className="py-24 bg-[#F5F5F0] border-b border-[#E5E2D9]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <p className="text-xs uppercase tracking-[0.25em] text-[#C5A059] font-semibold mb-2">
            The Historical Waterfront
          </p>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-[#1A1A1A] leading-tight text-balance">
            Location &amp; Concierge Inquiries
          </h2>
          <div className="w-16 h-0.5 bg-[#C5A059] mx-auto mt-4 mb-4" />
          <p className="text-neutral-600 text-sm sm:text-base font-light">
            Directly fronting the Gateway of India and the vast Arabian Sea, situated in historic South Mumbai.
          </p>
        </div>

        {/* 2-Column Split: Detailed Info Card & Interactive Google Maps Embed */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Left Column: Location & Contact Spec Card */}
          <div className="lg:col-span-5 bg-[#FAF9F6] border border-[#E5E2D9] rounded-sm p-6 sm:p-8 flex flex-col justify-between shadow-sm">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <span className="w-2.5 h-2.5 rounded-full bg-[#C5A059]" />
                <span className="text-xs uppercase tracking-widest text-neutral-500 font-semibold">
                  Heritage Landmark Destination
                </span>
              </div>

              <h3 className="font-serif text-2xl sm:text-3xl font-bold text-[#1A1A1A] mb-2">
                {HOTEL_INFO.name}
              </h3>

              {/* Social Proof */}
              <div className="flex items-center gap-2 text-xs sm:text-sm text-neutral-700 mb-6 pb-6 border-b border-[#EAE8E1]">
                <div className="flex items-center text-[#C5A059]">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-[#C5A059]" />
                  ))}
                </div>
                <span className="font-semibold text-[#1A1A1A]">4.7 / 5 Stars</span>
                <span className="text-neutral-400">·</span>
                <span className="text-neutral-600">35,000+ Verified Reviews</span>
              </div>

              {/* Verified Details */}
              <div className="space-y-4 text-xs sm:text-sm">
                <div className="flex items-start gap-3">
                  <MapPin className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-[#1A1A1A]">Full Address</p>
                    <p className="text-neutral-600 mt-0.5 leading-relaxed">
                      {HOTEL_INFO.address}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Phone className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-[#1A1A1A]">Palace Reservations &amp; Butler Desk</p>
                    <p className="text-neutral-600 mt-0.5">
                      {HOTEL_INFO.phone} (24/7 Dedicated Concierge)
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Compass className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-[#1A1A1A]">Coordinates &amp; Proximity</p>
                    <p className="text-neutral-600 mt-0.5 leading-relaxed">
                      18.9217° N, 72.8332° E · 25 km from Chhatrapati Shivaji Maharaj Int'l Airport (BOM)
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Clock className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-[#1A1A1A]">Check-in / Check-out</p>
                    <p className="text-neutral-600 mt-0.5">
                      Check-in: 14:00 | Check-out: 12:00 (Early/Late by request)
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* 3 Action Buttons */}
            <div className="pt-6 mt-6 border-t border-[#EAE8E1] grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <a
                href={`tel:${HOTEL_INFO.phoneClean}`}
                className="px-4 py-3 bg-[#1A1A1A] hover:bg-[#C5A059] text-white text-xs font-semibold uppercase tracking-wider rounded-sm transition-colors text-center flex items-center justify-center gap-1.5"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Call Now</span>
              </a>

              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-3 bg-[#1E7E34] hover:bg-[#155d27] text-white text-xs font-semibold uppercase tracking-wider rounded-sm transition-colors text-center flex items-center justify-center gap-1.5"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>WhatsApp Us</span>
              </a>

              <a
                href={directionsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-3 bg-white hover:bg-[#FAF9F6] text-[#1A1A1A] border border-[#C5A059] text-xs font-semibold uppercase tracking-wider rounded-sm transition-colors text-center flex items-center justify-center gap-1.5"
              >
                <Navigation className="w-3.5 h-3.5 text-[#C5A059]" />
                <span>Directions</span>
              </a>
            </div>
          </div>

          {/* Right Column: Embedded Google Maps Frame */}
          <div className="lg:col-span-7 bg-white rounded-sm overflow-hidden border border-[#E5E2D9] shadow-sm relative min-h-[380px] lg:min-h-full">
            <iframe
              title="The Taj Mahal Palace, Mumbai Waterfront Google Map"
              src="https://maps.google.com/maps?q=The%20Taj%20Mahal%20Palace%20Apollo%20Bunder%20Colaba%20Mumbai%20400001&t=&z=16&ie=UTF8&iwloc=&output=embed"
              className="w-full h-full min-h-[400px] border-0"
              loading="lazy"
              allowFullScreen
            />
          </div>
        </div>
      </div>
    </section>
  );
};
