import React from 'react';
import { HOTEL_INFO, HOTEL_REAL_IMAGES } from '../data/hotelData';
import { Star, ChevronDown, Compass } from 'lucide-react';

interface HeroProps {
  onReserveClick: () => void;
  onExploreSuitesClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onReserveClick, onExploreSuitesClick }) => {
  const scrollToHeritage = () => {
    const el = document.getElementById('heritage');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative min-h-[92vh] sm:min-h-screen flex items-center justify-center overflow-hidden">
      {/* Real Verified Waterfront Facade of The Taj Mahal Palace, Mumbai */}
      <div className="absolute inset-0 z-0">
        <img
          src={HOTEL_REAL_IMAGES.hero}
          alt="The Taj Mahal Palace Mumbai waterfront facade and iconic dome overlooking the Gateway of India"
          className="w-full h-full object-cover object-center transform scale-105 transition-transform duration-1000 ease-out"
          referrerPolicy="no-referrer"
        />
        {/* Measured dark luxury gradient scrim for WCAG AA typography contrast */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/45 to-black/60" />
      </div>

      {/* Hero Content */}
      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white pt-24 pb-20">
        {/* Location Badge (Clean unboxed text, no pills as per skill discipline) */}
        <div className="inline-flex items-center justify-center gap-2 text-xs sm:text-sm uppercase tracking-[0.25em] text-[#E8D3A2] mb-4">
          <Compass className="w-3.5 h-3.5 text-[#C5A059]" />
          <span>{HOTEL_INFO.locationBadge}</span>
          <span aria-hidden="true" className="text-[#C5A059]">·</span>
          <span>Est. {HOTEL_INFO.established}</span>
        </div>

        {/* Brand Name */}
        <p className="font-serif text-xl sm:text-2xl md:text-3xl text-white/95 tracking-widest uppercase mb-3">
          {HOTEL_INFO.name}
        </p>

        {/* Headline */}
        <h1 className="font-serif text-3xl sm:text-5xl md:text-6xl lg:text-7xl font-bold leading-tight tracking-tight text-white mb-6 text-balance max-w-4xl mx-auto drop-shadow-md">
          An Enduring Legend of Hospitality &amp; Elegance
        </h1>

        {/* Sub-headline */}
        <p className="text-base sm:text-lg md:text-xl text-neutral-100 font-light max-w-2xl mx-auto mb-8 leading-relaxed drop-shadow-sm">
          India’s premier luxury landmark overlooking the Arabian Sea and Gateway of India. A grand sanctuary where timeless heritage meets world-class luxury.
        </p>

        {/* Social Proof Tag */}
        <div className="inline-flex items-center justify-center gap-2 px-4 py-2 bg-black/60 backdrop-blur-md rounded-full border border-white/20 text-xs sm:text-sm text-neutral-100 mb-10 shadow-lg">
          <span className="flex items-center text-[#E8B959] gap-0.5" aria-hidden="true">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-3.5 h-3.5 fill-[#E8B959] text-[#E8B959]" />
            ))}
          </span>
          <span className="font-semibold text-white">4.7 / 5 Rating</span>
          <span aria-hidden="true" className="text-neutral-400">·</span>
          <span>Loved by {HOTEL_INFO.reviewsCount} Verified Guests</span>
        </div>

        {/* Action CTAs */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 max-w-md mx-auto">
          <button
            onClick={onReserveClick}
            className="w-full sm:w-auto px-8 py-3.5 bg-[#C5A059] hover:bg-[#a7823b] text-white text-xs sm:text-sm font-semibold uppercase tracking-widest rounded-sm shadow-xl transition-all duration-200 transform hover:-translate-y-0.5 active:translate-y-0"
            aria-label="Reserve your stay at The Taj Mahal Palace"
          >
            Reserve Your Stay
          </button>
          <button
            onClick={onExploreSuitesClick}
            className="w-full sm:w-auto px-8 py-3.5 bg-white/15 hover:bg-white/25 text-white backdrop-blur-sm border border-white/30 text-xs sm:text-sm font-semibold uppercase tracking-widest rounded-sm transition-all duration-200"
            aria-label="Explore palace suites and heritage rooms"
          >
            Explore Suites
          </button>
        </div>
      </div>

      {/* Interactive "Scroll to Explore" indicator with subtle pulse animation */}
      <button
        onClick={scrollToHeritage}
        aria-label="Scroll to explore heritage story"
        className="absolute bottom-6 left-1/2 transform -translate-x-1/2 z-10 flex flex-col items-center gap-2 text-white/90 hover:text-white transition-colors cursor-pointer group"
      >
        <span className="text-[11px] uppercase tracking-[0.2em] font-medium text-neutral-200 group-hover:text-white transition-colors">
          Scroll to Explore
        </span>
        <div className="w-9 h-9 rounded-full border border-white/40 group-hover:border-[#C5A059] flex items-center justify-center animate-bounce transition-colors">
          <ChevronDown className="w-4 h-4 text-[#C5A059]" />
        </div>
      </button>
    </section>
  );
};
