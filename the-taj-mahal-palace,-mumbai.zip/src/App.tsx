import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { PressAwardsStrip } from './components/PressAwardsStrip';
import { HeritageStory } from './components/HeritageStory';
import { RoomsSection } from './components/RoomsSection';
import { ExperientialPackages } from './components/ExperientialPackages';
import { DiningSection } from './components/DiningSection';
import { AmenitiesSection } from './components/AmenitiesSection';
import { TestimonialsSection } from './components/TestimonialsSection';
import { ConciergeFAQ } from './components/ConciergeFAQ';
import { LocationSection } from './components/LocationSection';
import { BookingSection } from './components/BookingSection';
import { ReservationModal } from './components/ReservationModal';
import { FloatingActions } from './components/FloatingActions';
import { Footer } from './components/Footer';
import { ExperientialPackage, ReservationData, Currency } from './types/hotel';

export default function App() {
  const [currency, setCurrency] = useState<Currency>('INR');
  const [preselectedSuite, setPreselectedSuite] = useState<string>('Luxury Room (Sea View)');
  const [preselectedSpecialRequest, setPreselectedSpecialRequest] = useState<string>('');
  const [activeReservation, setActiveReservation] = useState<ReservationData | null>(null);

  const scrollToBooking = () => {
    const bookingElement = document.getElementById('booking');
    if (bookingElement) {
      bookingElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToSuites = () => {
    const suitesElement = document.getElementById('suites');
    if (suitesElement) {
      suitesElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectSuite = (suiteName: string) => {
    setPreselectedSuite(suiteName);
    scrollToBooking();
  };

  const handleSelectPackage = (pkg: ExperientialPackage) => {
    setPreselectedSpecialRequest(`Experiential Package: ${pkg.title} (${pkg.duration}) - includes ${pkg.highlights[0]}`);
    scrollToBooking();
  };

  const handleSelectDish = (dishName: string) => {
    setPreselectedSpecialRequest(`Culinary inquiry: Table reservation & signature tasting of ${dishName}`);
    scrollToBooking();
  };

  const handleReservationSubmitted = (data: ReservationData) => {
    setActiveReservation(data);
  };

  return (
    <div className="min-h-screen bg-[#FAF9F6] text-[#1A1A1A] flex flex-col font-sans selection:bg-[#C5A059]/30 selection:text-[#1A1A1A]">
      {/* Frosted Glass Sticky Top Header with Global Currency Selector */}
      <Header
        onBookNowClick={scrollToBooking}
        currency={currency}
        onCurrencyChange={setCurrency}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {/* Full-bleed Hero Banner with Real Verified Waterfront Facade of The Taj Mahal Palace, Mumbai */}
        <Hero
          onReserveClick={scrollToBooking}
          onExploreSuitesClick={scrollToSuites}
        />

        {/* Authoritative Press & Awards Strip Carousel */}
        <PressAwardsStrip />

        {/* Heritage Story & Architectural Narrative */}
        <HeritageStory />

        {/* Suites & Heritage Rooms Showcase with Authentic Room Photos & Live Availability Badges */}
        <RoomsSection
          onSelectSuite={handleSelectSuite}
          currency={currency}
          onCurrencyChange={setCurrency}
        />

        {/* Experiential Packages Module: Royal Heritage Stay, Culinary Journey at Wasabi, Jiva Spa Retreat */}
        <ExperientialPackages
          onSelectPackage={handleSelectPackage}
          currency={currency}
          onCurrencyChange={setCurrency}
        />

        {/* Fine Dining Showcase with Filterable Menu Search & Real Culinary Photos */}
        <DiningSection
          onDishSelect={handleSelectDish}
          currency={currency}
          onCurrencyChange={setCurrency}
        />

        {/* Facilities & Iconic Palace Amenities Section */}
        <AmenitiesSection />

        {/* Guest Impressions & Verified Reviews with Category Choice Tabs (No Marquee) */}
        <TestimonialsSection />

        {/* Palace Concierge FAQ Section: Check-in, Wasabi Dress Code, Airport Transfers, Policies */}
        <ConciergeFAQ />

        {/* Location & Google Maps Interactive Integration */}
        <LocationSection />

        {/* Footer Direct Booking Form with Live Night & Currency Calculations */}
        <BookingSection
          preselectedSuite={preselectedSuite}
          preselectedSpecialRequest={preselectedSpecialRequest}
          currency={currency}
          onReservationSubmitted={handleReservationSubmitted}
        />
      </main>

      {/* Luxury Footer with 'Our Brands' Floating Loop */}
      <Footer />

      {/* Floating Quick Action Triggers for Call Now & WhatsApp */}
      <FloatingActions />

      {/* Confirmation Modal Pop-up on Reservation Submission */}
      {activeReservation && (
        <ReservationModal
          reservation={activeReservation}
          onClose={() => setActiveReservation(null)}
        />
      )}
    </div>
  );
}
