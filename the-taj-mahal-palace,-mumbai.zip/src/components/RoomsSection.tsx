import React, { useState } from 'react';
import { ROOMS, formatCurrency } from '../data/hotelData';
import { Room, Currency } from '../types/hotel';
import { Check, Users, Maximize, Eye, Sparkles, ArrowRight, X, BedDouble, AlertCircle } from 'lucide-react';

interface RoomsSectionProps {
  onSelectSuite: (roomName: string) => void;
  currency?: Currency;
  onCurrencyChange?: (currency: Currency) => void;
}

export const RoomsSection: React.FC<RoomsSectionProps> = ({
  onSelectSuite,
  currency = 'INR',
  onCurrencyChange,
}) => {
  const [selectedModalRoom, setSelectedModalRoom] = useState<Room | null>(null);
  const [localCurrency, setLocalCurrency] = useState<Currency>(currency);

  const activeCurrency = onCurrencyChange ? currency : localCurrency;
  const handleCurrencyToggle = (c: Currency) => {
    if (onCurrencyChange) {
      onCurrencyChange(c);
    } else {
      setLocalCurrency(c);
    }
  };

  const currencies: Currency[] = ['INR', 'USD', 'EUR', 'GBP'];

  return (
    <section id="suites" className="py-24 bg-[#F5F5F0] border-b border-[#E5E2D9]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <p className="text-xs uppercase tracking-[0.25em] text-[#8C651E] font-semibold mb-2">
              Palatial Accommodations
            </p>
            <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-[#1A1A1A] text-balance">
              Suites &amp; Heritage Rooms
            </h2>
            <div className="w-16 h-0.5 bg-[#C5A059] mt-4 mb-3" />
            <p className="text-neutral-700 text-sm sm:text-base max-w-xl font-light">
              Experience the pinnacle of royal heritage, bespoke butler service, and unhindered vistas of Mumbai’s historic harbour.
            </p>
          </div>

          {/* Interactive Currency Converter Toggle with 4 Currencies */}
          <div className="flex items-center gap-1.5 p-1 bg-white rounded-md border border-[#E0DDD5] self-start md:self-end shadow-xs" role="group" aria-label="Select currency for rooms">
            <span className="text-xs text-neutral-600 pl-2 pr-1 font-medium hidden sm:inline">Currency:</span>
            {currencies.map((curr) => (
              <button
                key={curr}
                onClick={() => handleCurrencyToggle(curr)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-xs transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059] focus-visible:ring-offset-2 ${
                  activeCurrency === curr
                    ? 'bg-[#C5A059] text-white shadow-xs'
                    : 'text-neutral-700 hover:text-black hover:bg-[#FAF9F6]'
                }`}
                aria-pressed={activeCurrency === curr}
                aria-label={`Display room prices in ${curr}`}
              >
                {curr === 'INR' ? '₹ INR' : curr === 'USD' ? '$ USD' : curr === 'EUR' ? '€ EUR' : '£ GBP'}
              </button>
            ))}
          </div>
        </div>

        {/* 4 Room Cards Grid (2x2 on desktop) */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {ROOMS.map((room) => {
            const formattedPrice = formatCurrency(room.pricePerNightINR, activeCurrency);

            return (
              <div
                key={room.id}
                className="bg-[#FAF9F6] border border-[#E5E2D9] rounded-sm overflow-hidden flex flex-col group hover:border-[#C5A059]/80 hover:shadow-xl transition-all duration-300"
              >
                {/* Room Image Container */}
                <div className="relative h-64 sm:h-72 overflow-hidden bg-neutral-900">
                  <img
                    src={room.image}
                    alt={`${room.name} at The Taj Mahal Palace, Mumbai`}
                    width="800"
                    height="600"
                    loading="lazy"
                    decoding="async"
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-black/30" />

                  {/* Live Availability Status Indicator Badge */}
                  {room.availabilitySignal && (
                    <div className="absolute top-3 left-3 z-10 flex items-center gap-1.5 px-3 py-1.5 bg-black/85 backdrop-blur-md text-[#F4DFC0] border border-[#C5A059]/70 rounded-xs text-[11px] font-medium shadow-md">
                      <span className="w-2 h-2 rounded-full bg-[#E5A93C] animate-pulse shrink-0" aria-hidden="true" />
                      <span>{room.availabilitySignal.text}</span>
                    </div>
                  )}

                  {/* Room View Overlay Tag */}
                  <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between text-white">
                    <div>
                      <p className="text-xs uppercase tracking-widest text-[#E8D3A2] font-semibold">
                        {room.specs.view}
                      </p>
                      <h3 className="font-serif text-xl sm:text-2xl font-bold mt-0.5">
                        {room.name}
                      </h3>
                    </div>
                    <button
                      onClick={() => setSelectedModalRoom(room)}
                      className="px-3 py-1.5 text-xs bg-white/20 hover:bg-white/30 backdrop-blur-md rounded-sm border border-white/30 font-medium transition-colors flex items-center gap-1 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059] focus-visible:ring-offset-2"
                      aria-label={`View full details of ${room.name}`}
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Details</span>
                    </button>
                  </div>
                </div>

                {/* Content Details */}
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    {/* Tagline */}
                    <p className="text-xs sm:text-sm text-neutral-700 italic font-serif mb-4">
                      "{room.tagline}"
                    </p>

                    {/* Room Specs - Clean unboxed metadata with separators */}
                    <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-neutral-700 mb-5 py-2.5 px-3 bg-[#F5F5F0] rounded-sm border border-[#EBE8E0]">
                      <span className="flex items-center gap-1 font-semibold text-neutral-900">
                        <BedDouble className="w-3.5 h-3.5 text-[#8C651E]" />
                        {room.specs.bed}
                      </span>
                      <span aria-hidden="true" className="text-neutral-400">·</span>
                      <span className="flex items-center gap-1 text-neutral-800">
                        <Users className="w-3.5 h-3.5 text-[#8C651E]" />
                        {room.specs.capacity}
                      </span>
                      <span aria-hidden="true" className="text-neutral-400">·</span>
                      <span className="flex items-center gap-1 text-neutral-800">
                        <Maximize className="w-3.5 h-3.5 text-[#8C651E]" />
                        {room.specs.area}
                      </span>
                    </div>

                    {/* Features List */}
                    <div className="mb-6">
                      <p className="text-[11px] uppercase tracking-wider font-semibold text-neutral-600 mb-2.5">
                        Suite Highlights
                      </p>
                      <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {room.features.map((feat, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-xs text-neutral-800">
                            <Check className="w-3.5 h-3.5 text-[#8C651E] shrink-0 mt-0.5" />
                            <span>{feat}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Price and CTA */}
                  <div className="pt-4 border-t border-[#E8E6DF] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <p className="text-[11px] uppercase tracking-wider text-neutral-600 font-medium">Starting from</p>
                      <p className="text-xl sm:text-2xl font-serif font-bold text-[#1A1A1A] tabular-nums">
                        {formattedPrice} <span className="text-xs font-sans font-normal text-neutral-600">/ night</span>
                      </p>
                    </div>

                    <button
                      onClick={() => onSelectSuite(room.name)}
                      className="px-6 py-3 bg-[#1A1A1A] hover:bg-[#C5A059] text-white text-xs font-semibold uppercase tracking-wider rounded-sm transition-all duration-200 flex items-center justify-center gap-2 group-hover:bg-[#C5A059] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059] focus-visible:ring-offset-2"
                      aria-label={`Reserve ${room.name}`}
                    >
                      <span>Reserve Suite</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Expanded Room Details Modal */}
      {selectedModalRoom && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200"
          role="dialog"
          aria-modal="true"
          aria-labelledby="modal-room-title"
        >
          <div className="bg-[#FAF9F6] border border-[#C5A059]/40 rounded-sm max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl relative">
            <button
              onClick={() => setSelectedModalRoom(null)}
              className="absolute top-4 right-4 z-10 w-8 h-8 rounded-full bg-black/60 hover:bg-black text-white flex items-center justify-center transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059]"
              aria-label="Close modal"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="relative h-64 sm:h-80 overflow-hidden bg-neutral-900">
              <img
                src={selectedModalRoom.image}
                alt={selectedModalRoom.name}
                width="800"
                height="600"
                loading="lazy"
                decoding="async"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
              
              {/* Availability Signal in Modal */}
              {selectedModalRoom.availabilitySignal && (
                <div className="absolute top-4 left-4 z-10 flex items-center gap-1.5 px-3 py-1 bg-black/85 backdrop-blur-md text-[#F4DFC0] border border-[#C5A059]/70 rounded-xs text-[11px] font-medium">
                  <span className="w-2 h-2 rounded-full bg-[#E5A93C] animate-pulse" />
                  <span>{selectedModalRoom.availabilitySignal.text}</span>
                </div>
              )}

              <div className="absolute bottom-6 left-6 right-6 text-white">
                <span className="text-xs uppercase tracking-widest text-[#E8D3A2]">{selectedModalRoom.specs.view}</span>
                <h3 id="modal-room-title" className="font-serif text-2xl sm:text-3xl font-bold mt-1">{selectedModalRoom.name}</h3>
              </div>
            </div>

            <div className="p-6 sm:p-8 space-y-6">
              <p className="text-sm sm:text-base text-neutral-800 leading-relaxed font-light">
                {selectedModalRoom.description}
              </p>

              <div className="grid grid-cols-3 gap-3 p-3 bg-[#F5F5F0] rounded-sm border border-[#E5E2D9] text-center">
                <div>
                  <p className="text-[11px] uppercase tracking-wider text-neutral-600">Bedding</p>
                  <p className="text-xs sm:text-sm font-semibold text-[#1A1A1A] mt-0.5">{selectedModalRoom.specs.bed}</p>
                </div>
                <div>
                  <p className="text-[11px] uppercase tracking-wider text-neutral-600">Occupancy</p>
                  <p className="text-xs sm:text-sm font-semibold text-[#1A1A1A] mt-0.5">{selectedModalRoom.specs.capacity}</p>
                </div>
                <div>
                  <p className="text-[11px] uppercase tracking-wider text-neutral-600">Dimensions</p>
                  <p className="text-xs sm:text-sm font-semibold text-[#1A1A1A] mt-0.5">{selectedModalRoom.specs.area}</p>
                </div>
              </div>

              <div>
                <h4 className="text-xs uppercase tracking-wider font-semibold text-[#1A1A1A] mb-3">
                  Privileges &amp; Heritage Inclusions
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {selectedModalRoom.features.map((feat, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-xs text-neutral-800">
                      <Sparkles className="w-3.5 h-3.5 text-[#8C651E] shrink-0" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-4 border-t border-[#E8E6DF] flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <span className="text-xs text-neutral-600">Nightly Rate:</span>
                  <p className="font-serif text-2xl font-bold text-[#1A1A1A]">
                    {formatCurrency(selectedModalRoom.pricePerNightINR, activeCurrency)}
                  </p>
                </div>

                <button
                  onClick={() => {
                    onSelectSuite(selectedModalRoom.name);
                    setSelectedModalRoom(null);
                  }}
                  className="w-full sm:w-auto px-6 py-3 bg-[#C5A059] hover:bg-[#a7823b] text-white text-xs font-semibold uppercase tracking-wider rounded-sm transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059] focus-visible:ring-offset-2"
                >
                  Reserve This Suite
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
