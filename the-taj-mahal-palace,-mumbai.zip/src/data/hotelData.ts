import {
  Room,
  Dish,
  Amenity,
  Testimonial,
  CategorizedTestimonial,
  ExperientialPackage,
  AwardItem,
  FAQItem,
  Currency
} from '../types/hotel';

// Bundled authentic images of The Taj Mahal Palace, Mumbai
import heroImg from '../assets/images/taj_palace_hero_1791549690254.jpg';
import poolCourtyardImg from '../assets/images/taj_courtyard_pool_1791549747566.jpg';
import fineDiningImg from '../assets/images/taj_fine_dining_1791549736338.jpg';

// The 4 room images corresponding to the user's authentic room photos
import room1Img from '../assets/images/taj_room1_luxury_1791560294939.jpg';
import room2Img from '../assets/images/taj_room2_club_1791560310716.jpg';
import room3Img from '../assets/images/taj_room3_gateway_1791560328658.jpg';
import room4Img from '../assets/images/taj_room4_presidential_1791560346526.jpg';

// Authentic dish visuals for the food menu
import murghMakhaniImg from '../assets/images/taj_dish_murgh_makhani_1791549803570.jpg';
import biryaniImg from '../assets/images/taj_dish_biryani_1791549790134.jpg';
import lobsterImg from '../assets/images/taj_dish_lobster_1791550002963.jpg';
import rasmalaiImg from '../assets/images/taj_dessert_rasmalai_1791550030981.jpg';
import sushiImg from '../assets/images/taj_dish_sushi_wasabi_1791549815806.jpg';
import pastaImg from '../assets/images/taj_dish_pasta_1791550015719.jpg';
import lambChopsImg from '../assets/images/taj_dish_lamb_chops_1791549828076.jpg';
import caesarSaladImg from '../assets/images/taj_dish_caesar_salad_1791555386097.jpg';
import breakfastPlatterImg from '../assets/images/taj_dish_breakfast_platter_1791555397893.jpg';

export const HOTEL_REAL_IMAGES = {
  hero: heroImg,
  facadeFrontal: heroImg,
  harbourView: heroImg,
  poolCourtyard: poolCourtyardImg,
  fineDining: fineDiningImg,
  room1: room1Img,
  room2: room2Img,
  room3: room3Img,
  room4: room4Img,
};

export const HOTEL_INFO = {
  name: 'The Taj Mahal Palace, Mumbai',
  tagline: 'An Enduring Legend of Hospitality & Elegance',
  locationBadge: 'Apollo Bunder · Colaba, Mumbai, Maharashtra',
  address: 'Apollo Bunder, Colaba, Mumbai, Maharashtra 400001, India',
  phone: '+91 22 6665 3366',
  phoneDisplay: '+91 22 6665 3366',
  phoneClean: '912266653366',
  email: 'reservations.mumbai@tajhotels.com',
  rating: 4.7,
  reviewsCount: '35,000+',
  established: 1903,
  founder: 'Jamsetji Nusserwanji Tata',
  coordinates: {
    lat: 18.9217,
    lng: 72.8332
  }
};

// Currency Exchange Rates (Base: INR)
export const CURRENCY_RATES: Record<Currency, { symbol: string; rate: number; label: string }> = {
  INR: { symbol: '₹', rate: 1, label: 'INR (₹)' },
  USD: { symbol: '$', rate: 0.012, label: 'USD ($)' },
  EUR: { symbol: '€', rate: 0.011, label: 'EUR (€)' },
  GBP: { symbol: '£', rate: 0.0093, label: 'GBP (£)' },
};

export const formatCurrency = (amountINR: number, currency: Currency): string => {
  const config = CURRENCY_RATES[currency];
  const converted = amountINR * config.rate;
  if (currency === 'INR') {
    return `₹${Math.round(converted).toLocaleString('en-IN')}`;
  }
  return `${config.symbol}${Math.round(converted).toLocaleString('en-US')}`;
};

// Press & Authoritative Awards Strip Data
export const PRESS_AWARDS: AwardItem[] = [
  {
    id: 'cnt-gold-list',
    year: '2026',
    organization: 'Condé Nast Traveler',
    title: 'Gold List of the World’s Best Hotels',
    category: 'Heritage Luxury & Timeless Hospitality',
    badge: 'Gold List'
  },
  {
    id: 'travel-leisure',
    year: '2025',
    organization: 'Travel + Leisure',
    title: '#1 City Hotel in India & Top 5 in Asia',
    category: 'World’s Best Awards',
    badge: 'World’s Best'
  },
  {
    id: 'michelin-guide',
    year: '2026',
    organization: 'Michelin Guide Selected',
    title: 'Culinary Distinction — Wasabi by Morimoto',
    category: 'Master Japanese Gastronomy',
    badge: 'Michelin Selection'
  },
  {
    id: 'forbes-travel',
    year: '2026',
    organization: 'Forbes Travel Guide',
    title: 'Five-Star Award of Excellence',
    category: 'Ultra-Luxury Hotel & Spa Sanctuary',
    badge: '5-Star Verified'
  },
  {
    id: 'world-travel-awards',
    year: '2025',
    organization: 'World Travel Awards',
    title: 'Asia’s Leading Heritage Landmark Hotel',
    category: 'Palatial Hospitality Winner',
    badge: 'Leading Landmark'
  },
  {
    id: 'natgeo-traveler',
    year: '2024',
    organization: 'National Geographic Traveler',
    title: 'Top 10 Historic Sanctuaries of the Orient',
    category: 'Architectural Preservation',
    badge: 'Iconic Stay'
  }
];

export const EXPERIENTIAL_PACKAGES: ExperientialPackage[] = [
  {
    id: 'royal-heritage-stay',
    title: 'Royal Heritage Stay',
    subtitle: 'A Regal Odyssey in Mumbai',
    tagline: 'Immerse in century-old imperial grandeur overlooking the Gateway of India',
    duration: '3 Days · 2 Nights',
    priceINR: 115000,
    badge: 'Signature Experience',
    image: heroImg,
    highlights: [
      'Accommodations in Heritage Sea View Suite with Arabian Sea vistas',
      'Private walking tour with resident Palace Historian through art archives',
      'Sunset private motor yacht sail on Mumbai Harbour with champagne',
      'Traditional English Afternoon High Tea ceremony at the historic Sea Lounge',
      '24/7 dedicated Palace Butler service and private airport limousine transfers'
    ],
    description: 'Relive the golden era of maharajas and royalty with an all-inclusive heritage immersion. Walk through historic corridors housing 4,000 pieces of museum-quality Indian art and watch the sunrise over the Gateway of India from your private parlor.'
  },
  {
    id: 'culinary-journey-wasabi',
    title: 'Culinary Journey at Wasabi',
    subtitle: 'Master Gastronomy with Chef Morimoto',
    tagline: 'An epicurean expedition across Tokyo flavours and coastal Mumbai catch',
    duration: '2 Days · 1 Night',
    priceINR: 78000,
    badge: 'Epicurean Journey',
    image: sushiImg,
    highlights: [
      '7-course Omakase Chef’s Tasting Menu at Wasabi by Morimoto with sea views',
      'Rare Japanese Sake flight & sommelier wine pairing curated tableside',
      'Masterclass & kitchen tour with Wasabi’s resident Japanese Executive Chef',
      'Pre-dinner vintage cocktails at Harbour Bar (India’s 1st licensed bar)',
      'Luxury Palace room accommodation with gourmet breakfast at Shamiana'
    ],
    description: 'An exclusive culinary retreat crafted for fine dining connoisseurs. Savor bluefin tuna and wagyu air-flown from Tokyo’s Toyosu Market, expertly paired with rare artisanal sakes in an intimate waterfront atmosphere.'
  },
  {
    id: 'jiva-spa-wellness-retreat',
    title: 'Jiva Spa Wellness Retreat',
    subtitle: 'Ancient Ayurvedic Rejuvenation',
    tagline: 'Harmonize mind, body, and spirit within our tranquil palace sanctuary',
    duration: '3 Days · 2 Nights',
    priceINR: 96000,
    badge: 'Holistic Wellness',
    image: poolCourtyardImg,
    highlights: [
      'Private Prakriti pulse consultation with resident Ayurvedic Vaidya doctor',
      '120-minute signature Vishram muscle melt massage with herbal compress',
      'Daily sunrise Yoga & Pranayama sessions at the historic pool colonnade',
      'Customized organic wellness dining plan curated by Taj nutritionists',
      'Hydrotherapy steam, sauna, and floral milk soaking ritual'
    ],
    description: 'Rooted in 5,000 years of traditional Indian healing wisdom. Surrender to soothing botanical oils, warm herbal poultices, and guided restorative meditation within the secluded palace courtyard gardens.'
  }
];

export const ROOMS: Room[] = [
  {
    id: 'luxury-sea-view',
    name: 'Luxury Room (Sea View)',
    category: 'Luxury Room (Sea View)',
    tagline: 'Authentic heritage room with direct balcony vista of the Gateway of India.',
    specs: {
      bed: 'King Bed',
      capacity: 'Sleeps 2',
      area: '380 sq. ft.',
      view: 'Direct Gateway of India & Arabian Sea'
    },
    features: [
      'Panoramic Gateway of India Balcony Views',
      'Handcrafted Rosewood Heritage Bed',
      'Italian Marble Bathroom',
      'High-Speed Fiber Wi-Fi',
      'Walk-in Closet & Silk Linens'
    ],
    pricePerNightINR: 38500,
    image: room3Img,
    description: 'Imbued with historic charm, the Luxury Sea View Room offers panoramic vistas directly over the Gateway of India, ornate mahogany furnishings, an exquisite marble bathroom with soaking tub, and signature Taj hospitality.',
    availabilitySignal: {
      status: 'high-demand',
      text: 'High Demand for Weekend Stays · 3 left'
    }
  },
  {
    id: 'taj-club-room',
    name: 'Taj Club Room',
    category: 'Taj Club Room',
    tagline: 'Refined living paired with chaise lounge, scenic vistas, and butler service.',
    specs: {
      bed: 'King Bed',
      capacity: 'Sleeps 2 + 1',
      area: '420 sq. ft.',
      view: 'Scenic Landscape & City Horizon'
    },
    features: [
      '24/7 Dedicated Palace Butler',
      'Sculptural Art & Chaise Lounge Window Nook',
      'Exclusive Taj Club Lounge Access',
      'Afternoon High Tea & Evening Cocktails',
      'Airport Limousine Transfers'
    ],
    pricePerNightINR: 52000,
    image: room2Img,
    description: 'Tailored for discerning travelers, featuring a contemporary chaise lounge next to a panoramic picture window, metallic sculptural art, complimentary access to the private Taj Club Lounge, and dedicated butler service.',
    availabilitySignal: {
      status: 'limited',
      text: 'Popular: 5 bookings confirmed today'
    }
  },
  {
    id: 'executive-suite',
    name: 'Executive Suite',
    category: 'Executive Suite',
    tagline: 'A spacious, opulent suite featuring wood paneling and executive desk.',
    specs: {
      bed: 'King Bed + Executive Lounge',
      capacity: 'Sleeps 3',
      area: '680 sq. ft.',
      view: 'Verdant Cityscape & Mumbai Skyline'
    },
    features: [
      'Wood-Paneled Feature Wall & Brass Sconces',
      'Dedicated Executive Desk & Dining Area',
      'Grand Royal Interiors with Fine Art Prints',
      'Priority Restaurant & Spa Reservations'
    ],
    pricePerNightINR: 85000,
    image: room1Img,
    description: 'A stately heritage sanctuary appointed with rich wood-paneled walls, warm geometric carpets, custom work bureau with fruit basket, a grand separate parlor for entertaining, and priority seating across all palace fine-dining venues.',
    availabilitySignal: {
      status: 'low-inventory',
      text: 'Only 2 suites remaining for selected dates'
    }
  },
  {
    id: 'grand-presidential-suite',
    name: 'Grand Presidential Suite',
    category: 'Grand Presidential Suite',
    tagline: 'The pinnacle of palatial luxury featuring the iconic circular canopy bed.',
    specs: {
      bed: 'Royal Circular Canopy Bed',
      capacity: 'Sleeps 4',
      area: '1,500+ sq. ft.',
      view: 'Unobstructed Gateway of India & Arabian Sea'
    },
    features: [
      'Iconic Circular Bed with Draped Gold Silk Canopy',
      'Domed Ceiling with Hand-Painted Gold Leaf Frescoes',
      'Antique Secretary Bureau & Persian Silk Carpet',
      'Private Dining Salon & Personal Butler Team',
      'In-Suite Spa Treatment Setup'
    ],
    pricePerNightINR: 275000,
    image: room4Img,
    description: 'The crowning jewel of the palace. Frequented by heads of state, royalty, and cultural icons. Featuring the legendary circular master bed beneath a gold-frescoed dome, antique bureau desk, hand-tufted carpets, and an entire dedicated butler and service retinue.',
    availabilitySignal: {
      status: 'low-inventory',
      text: 'Only 1 Presidential Suite available'
    }
  }
];

export const DISHES: Dish[] = [
  // Tab 1: Indian & Regional Delicacies
  {
    id: 'murgh-makhani',
    name: 'Murgh Makhani',
    tagline: 'Velveteen Clay-Oven Chicken in Tomato Butter Reduction',
    cuisineTab: 'indian',
    restaurant: 'Shamiana',
    description: 'Classic tender clay-oven chicken in a velvet tomato and butter gravy, simmered with dried fenugreek leaves and fragrant garam masala.',
    image: murghMakhaniImg,
    priceINR: 1950,
    dietary: 'Non-Vegetarian',
    tags: ['Signature', 'Clay Oven', 'Mughlai', 'Chicken', 'Curry'],
    chefNote: 'Prepared following the iconic 1950s palace recipe with slow-roasted makhani reduction.'
  },
  {
    id: 'nalli-nihari',
    name: 'Nalli Nihari',
    tagline: 'Slow-Simmered Royal Lamb Shanks with Saffron Gravy',
    cuisineTab: 'indian',
    restaurant: 'Shamiana',
    description: 'Slow-cooked lamb shanks infused with royal spices, herbs, and saffron, slow-braised overnight until falling off the bone.',
    image: biryaniImg,
    priceINR: 2450,
    dietary: 'Non-Vegetarian',
    tags: ['Royal Heritage', 'Slow Braised', 'Spiced', 'Lamb', 'Mutton'],
    chefNote: 'Infused with royal potli masala and Kashmiri saffron oil.'
  },
  {
    id: 'tandoori-lobster',
    name: 'Tandoori Lobster',
    tagline: 'Arabian Sea Spiced Fresh Catch Roasted in Clay Kiln',
    cuisineTab: 'indian',
    restaurant: 'Harbour Bar',
    description: 'Fresh Arabian Sea lobster marinated in aromatic spices, hung curd, and kashmiri chili, roasted in a traditional charcoal tandoor.',
    image: lobsterImg,
    priceINR: 3600,
    dietary: 'Seafood',
    tags: ['Fresh Catch', 'Tandoor', 'Gluten-Free', 'Lobster', 'Seafood'],
    chefNote: 'Sourced daily from Mumbai docks at sunrise and basted with smoked ghee.'
  },
  {
    id: 'dal-taj',
    name: 'Dal Taj',
    tagline: 'Signature 36-Hour Slow-Simmered Black Lentils',
    cuisineTab: 'indian',
    restaurant: 'Shamiana',
    description: 'Signature black lentils slow-simmered overnight with cream, churned butter, garlic, and gentle palace spices.',
    image: fineDiningImg,
    priceINR: 1450,
    dietary: 'Vegetarian',
    tags: ['House Legend', 'Vegetarian', 'Slow Cooked', 'Dal', 'Lentils'],
    chefNote: 'Slow simmered over smoldering charcoal for 36 hours for creamy depth.'
  },
  {
    id: 'hyderabadi-dum-biryani',
    name: 'Hyderabadi Dum Biryani',
    tagline: 'Sealed Handi Dum Fragrant Basmati with Spiced Meat',
    cuisineTab: 'indian',
    restaurant: 'Shamiana',
    description: 'Fragrant basmati rice layered with spiced meat, saffron, mint, and caramelized fried onions, sealed in a clay handi.',
    image: biryaniImg,
    priceINR: 2250,
    dietary: 'Non-Vegetarian',
    tags: ['Nizami Classic', 'Aromatics', 'Dum Pukht', 'Biryani', 'Rice'],
    chefNote: 'Layered with pure saffron milk and sealed with dough for the purist dum technique.'
  },
  {
    id: 'kulfi-falooda-rasmalai',
    name: 'Kulfi Falooda & Saffron Rasmalai',
    tagline: 'Pistachio Clotted Milk Dumplings & Rose Essence Falooda',
    cuisineTab: 'indian',
    restaurant: 'Sea Lounge',
    description: 'Artisanal Kulfi Falooda drizzled with organic rose syrup alongside Saffron Rasmalai dumplings immersed in cardamom pistachio milk.',
    image: rasmalaiImg,
    priceINR: 1250,
    dietary: 'Dessert',
    tags: ['Royal Sweets', 'Vegetarian', 'Saffron', 'Dessert', 'Rasmalai', 'Kulfi'],
    chefNote: 'Garnished with 24k edible silver vark and Iranian saffron threads.'
  },

  // Tab 2: International & Continental Classics
  {
    id: 'japanese-sushi-sashimi',
    name: 'Japanese Sushi & Sashimi',
    tagline: 'Bluefin Tuna, Scottish Salmon & Hamachi Master Platter',
    cuisineTab: 'international',
    restaurant: 'Wasabi by Morimoto',
    description: 'Fresh bluefin tuna and Atlantic salmon rolls prepared by master chefs, served with fresh grated Shizuoka wasabi, aged soy, and sake pairing.',
    image: sushiImg,
    priceINR: 4200,
    dietary: 'Seafood',
    tags: ['Wasabi by Morimoto', 'Master Plated', 'Air-Flown', 'Sushi', 'Sashimi', 'Sake', 'Japanese'],
    chefNote: 'Fish flown in directly twice weekly from Tokyo Toyosu Market.'
  },
  {
    id: 'handcrafted-pasta',
    name: 'Hand-Crafted Pasta',
    tagline: 'Truffle & Forest Wild Mushroom Tagliatelle in Aged Parmigiano',
    cuisineTab: 'international',
    restaurant: 'Shamiana',
    description: 'Truffle and wild mushroom tagliatelle served in a light parmesan emulsion with hand-shaved Norcia black truffles.',
    image: pastaImg,
    priceINR: 2400,
    dietary: 'Vegetarian',
    tags: ['Artisanal', 'Truffle', 'Handmade', 'Pasta', 'Tagliatelle', 'Italian'],
    chefNote: 'Fresh egg pasta rolled daily by hand in the palace pastificio.'
  },
  {
    id: 'grilled-australian-lamb-chops',
    name: 'Grilled Australian Lamb Chops',
    tagline: 'Herb-Crusted Lamb with Garlic Pomme Puree & Rosemary Jus',
    cuisineTab: 'international',
    restaurant: 'Harbour Bar',
    description: 'Served over garlic-infused potato puree with rosemary reduction, roasted heirloom baby carrots, and thyme.',
    image: lambChopsImg,
    priceINR: 3800,
    dietary: 'Non-Vegetarian',
    tags: ['Prime Cut', 'Continental', 'Char-Grilled', 'Lamb', 'Steak'],
    chefNote: 'Pasture-fed Australian lamb char-grilled over hickory wood coals.'
  },
  {
    id: 'classic-caesar-salad',
    name: 'Classic Caesar Salad',
    tagline: 'Crisp Romaine, Herb Brioche Croutons & Aged Reggiano Shavings',
    cuisineTab: 'international',
    restaurant: 'Shamiana',
    description: 'Crisp romaine hearts, herb garlic croutons, aged parmesan shavings, and house-made creamy garlic anchovy dressing.',
    image: caesarSaladImg,
    priceINR: 1350,
    dietary: 'Vegetarian',
    tags: ['Garden Fresh', 'Continental', 'Light', 'Salad', 'Healthy', 'Vegetarian'],
    chefNote: 'Tossed tableside with 24-month aged Parmigiano-Reggiano at Shamiana overlooking Gateway.'
  },
  {
    id: 'luxury-breakfast-platter',
    name: 'Luxury Breakfast Platter',
    tagline: 'Eggs Benedict, Belgian Waffles, Artisan Viennoiserie & Elixirs',
    cuisineTab: 'international',
    restaurant: 'Sea Lounge',
    description: 'Made-to-order Eggs Benedict, Belgian waffles, artisan pastries, fresh berry compote, smoked salmon, and cold-pressed Valencia orange juice.',
    image: breakfastPlatterImg,
    priceINR: 2600,
    dietary: 'Non-Vegetarian',
    tags: ['Palace Morning', 'Gourmet', 'Platter', 'Breakfast', 'Eggs Benedict', 'Waffles'],
    chefNote: 'Available daily with panoramic sunrise views over Mumbai Harbor at Sea Lounge.'
  }
];

export const AMENITIES: Amenity[] = [
  {
    id: 'jiva-spa',
    title: 'Jiva Spa & Wellness Center',
    tagline: 'Ancient Indian Healing Therapies',
    description: 'Traditional Indian therapies, holistic Ayurveda treatments, steam rooms, and yoga sessions led by resident wellness masters.',
    iconName: 'Sparkles',
    hours: '07:00 AM – 10:00 PM'
  },
  {
    id: 'palace-butler',
    title: '24/7 Palace Butler Service',
    tagline: 'Intuitive Imperial Hospitality',
    description: 'Personalized round-the-clock butler assistance tailored to guest preferences, from bespoke packing to private museum tours.',
    iconName: 'UserCheck',
    hours: '24 Hours Dedicated'
  },
  {
    id: 'outdoor-pool',
    title: 'Landscaped Outdoor Pool',
    tagline: 'Historic Courtyard Sanctuary',
    description: 'Resort-style outdoor pool surrounded by historic stone arches, lush tropical palms, sun loungers, and poolside refreshments.',
    iconName: 'Waves',
    hours: '06:30 AM – 09:00 PM'
  },
  {
    id: 'fitness-center',
    title: 'State-of-the-Art Fitness Center',
    tagline: 'Technogym Equipment & Personal Trainers',
    description: 'Fully equipped gym with personal trainers, wellness facilities, steam room, and tailored private fitness programs.',
    iconName: 'Activity',
    hours: '24 Hours Open'
  },
  {
    id: 'grand-ballroom',
    title: 'Grand Ballroom & Historic Venues',
    tagline: 'Legendary Royal Galas & Summits',
    description: 'Iconic spaces designed for royal weddings, high-profile summits, and private galas with vaulted ceilings and crystal chandeliers.',
    iconName: 'Award',
    hours: 'By Event Appointment'
  },
  {
    id: 'shopping-arcade',
    title: 'Luxury Shopping Arcade',
    tagline: 'Haute Horlogerie & Indian Couturiers',
    description: 'In-house high-end boutiques featuring international designer brands, fine jewelry, rare gemstones, and handcrafted Indian textiles.',
    iconName: 'ShoppingBag',
    hours: '10:00 AM – 09:00 PM'
  },
  {
    id: 'in-room-dining',
    title: '24-Hour In-Room Dining',
    tagline: 'Private Suite Gastronomy',
    description: 'Gourmet meals and late-night culinary service delivered straight to suites with white-glove silver service.',
    iconName: 'UtensilsCrossed',
    hours: '24 Hours Continuous'
  },
  {
    id: 'valet-limousine',
    title: 'Valet Parking & Airport Limousine Service',
    tagline: 'Chauffeured Luxury Transfers',
    description: 'Private chauffeur transfers in palace Rolls-Royce and BMW luxury fleets, accompanied by secure on-site valet parking.',
    iconName: 'Car',
    hours: '24 Hours Available'
  }
];

export const CONCIERGE_FAQS: FAQItem[] = [
  {
    id: 'faq-1',
    category: 'Check-in & Stays',
    question: 'What are the official check-in and check-out timings? Can I request early arrival?',
    answer: 'Standard check-in commences at 14:00 hrs and check-out is at 12:00 hrs. Early check-in and late departures are extended complimentary subject to suite availability. For guaranteed early morning arrival, we recommend booking the previous night or coordinating with your dedicated 24/7 Palace Butler for lounge hospitality and luggage reception.'
  },
  {
    id: 'faq-2',
    category: 'Dining & Dress Code',
    question: 'What are the dress codes for Wasabi by Morimoto and the historic Sea Lounge?',
    answer: 'At Wasabi by Morimoto, Golden Dragon, and Harbour Bar, the evening dress code is Smart Casual / Elegant Evening Attire (collared shirts, trousers, and closed footwear for gentlemen; no beachwear or athletic attire). For Afternoon High Tea at Sea Lounge, smart casual daywear is appreciated to maintain the stately heritage ambiance.'
  },
  {
    id: 'faq-3',
    category: 'Airport & Location',
    question: 'How far is the hotel from Mumbai Airport, and what limousine transfers are available?',
    answer: 'The Taj Mahal Palace is located at Apollo Bunder in South Mumbai, approximately 25 kilometers (approx. 45–60 minutes via the Coastal Road & Eastern Freeway) from Chhatrapati Shivaji Maharaj International Airport (BOM). The hotel maintains a private chauffeur-driven fleet featuring the Palace Rolls-Royce Phantom, BMW 7-Series, and luxury coaches with high-speed Wi-Fi and chilled refreshments.'
  },
  {
    id: 'faq-4',
    category: 'Policies & Concierge',
    question: 'What is the hotel pet policy and accommodation for service animals?',
    answer: 'To preserve the delicate historical antique furnishings, silk carpets, and heritage archives, pets are generally not permitted in the palace wing. Certified guide dogs and official service animals are warmly welcomed with prior notification to the Concierge desk to ensure tailored in-room setup.'
  },
  {
    id: 'faq-5',
    category: 'Dining & Dress Code',
    question: 'Are table reservations required for Sea Lounge High Tea and Wasabi by Morimoto?',
    answer: 'Yes, reservations are highly recommended due to high demand. Resident palace and suite guests receive priority table allocations. Non-resident visitors are encouraged to book at least 48 to 72 hours in advance, especially for weekend sunset windows overlooking the Gateway of India.'
  },
  {
    id: 'faq-6',
    category: 'Policies & Concierge',
    question: 'Can guests take professional photos or tour the private Palace Art Archives?',
    answer: 'Personal souvenir photography in public guest areas and hotel balconies is welcomed. Commercial photography or wedding shoots require prior authorization from palace management. Resident guests are entitled to a complimentary private historical art tour with the resident Palace Historian across our 4,000-piece museum collection upon request at the Butler desk.'
  }
];

// All 9 verified reviews categorized into tabs
export const TESTIMONIALS_DATA: CategorizedTestimonial[] = [
  {
    id: 'review-1',
    category: 'suites',
    quote: 'Staying at The Taj Mahal Palace is a regal experience like no other. Waking up to the sunrise over the Gateway of India is pure magic.',
    author: 'Lord Charles Sterling',
    stayDetail: 'Grand Presidential Suite · 3 Nights',
    rating: 5
  },
  {
    id: 'review-2',
    category: 'suites',
    quote: 'The level of hospitality provided by the Palace Butler team is unparalleled. Every detail of our stay was executed flawlessly.',
    author: 'Meera Kapoor',
    stayDetail: 'Taj Club Room · 2 Nights',
    rating: 5
  },
  {
    id: 'review-3',
    category: 'dining',
    quote: 'The dining at Wasabi and Shamiana was extraordinary. An iconic landmark that truly lives up to its reputation.',
    author: 'Vikram Singhania',
    stayDetail: 'Executive Suite · 4 Nights',
    rating: 5
  },
  {
    id: 'review-4',
    category: 'suites',
    quote: 'From the moment we arrived, we were treated like royalty. The Jiva Spa massage was divine!',
    author: 'Elena Rostova',
    stayDetail: 'Luxury Room Sea View · 2 Nights',
    rating: 5
  },
  {
    id: 'review-5',
    category: 'celebrations',
    quote: 'We hosted our corporate summit in the Grand Ballroom. World-class setup, sublime catering, and impeccable service.',
    author: 'Rajesh Merchant',
    stayDetail: 'Event Planner',
    rating: 5
  },
  {
    id: 'review-6',
    category: 'celebrations',
    quote: 'An unforgettable anniversary stay. The sea views, heritage architecture, and evening high tea at Sea Lounge were highlight moments.',
    author: 'Ananya & Devraj',
    stayDetail: 'Executive Suite · 2 Nights',
    rating: 5
  },
  {
    id: 'review-7',
    category: 'suites',
    quote: 'Spotless luxury, soft linens, and incredible historical charm. Staying here is an absolute bucket-list experience.',
    author: 'David Miller',
    stayDetail: 'Luxury Room Sea View · 3 Nights',
    rating: 5
  },
  {
    id: 'review-8',
    category: 'dining',
    quote: 'The high tea spread and signature Dal Taj were out of this world. Can’t wait to return!',
    author: 'Pooja Hegde',
    stayDetail: 'Taj Club Room · 1 Night',
    rating: 5
  },
  {
    id: 'review-9',
    category: 'suites',
    quote: 'The concierge arranged our private city tour and boat excursion seamlessly. Exceptional heritage hospitality.',
    author: 'Karan & Natasha',
    stayDetail: 'Taj Club Room · 3 Nights',
    rating: 5
  }
];
