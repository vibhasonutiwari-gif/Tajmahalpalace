import React, { useState, useEffect } from 'react';
import { HOTEL_INFO } from '../data/hotelData';
import { Currency } from '../types/hotel';
import { Menu, X, Phone, CalendarCheck, Globe } from 'lucide-react';

interface HeaderProps {
  onBookNowClick: () => void;
  currency: Currency;
  onCurrencyChange: (currency: Currency) => void;
}

export const Header: React.FC<HeaderProps> = ({
  onBookNowClick,
  currency,
  onCurrencyChange,
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Suites', href: '#suites' },
    { label: 'Packages', href: '#packages' },
    { label: 'Dining', href: '#dining' },
    { label: 'Facilities', href: '#facilities' },
    { label: 'Awards', href: '#awards' },
    { label: 'FAQ', href: '#faq' },
    { label: 'Location', href: '#location' },
  ];

  const currencies: { id: Currency; label: string }[] = [
    { id: 'INR', label: '₹ INR' },
    { id: 'USD', label: '$ USD' },
    { id: 'EUR', label: '€ EUR' },
    { id: 'GBP', label: '£ GBP' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#FAF9F6]/95 backdrop-blur-md shadow-sm border-b border-[#C5A059]/30 py-3'
          : 'bg-gradient-to-b from-black/80 via-black/50 to-transparent py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-4 lg:gap-8">
          {/* Zone 1: Wordmark */}
          <a
            href="#"
            className={`font-serif text-lg sm:text-2xl font-bold tracking-wider uppercase transition-colors whitespace-nowrap shrink-0 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059] focus-visible:ring-offset-2 ${
              isScrolled ? 'text-[#1A1A1A]' : 'text-white'
            }`}
            aria-label="The Taj Mahal Palace, Mumbai Home"
          >
            The Taj Mahal Palace
          </a>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden xl:flex items-center gap-5 text-xs lg:text-sm font-medium" aria-label="Main navigation">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className={`transition-colors whitespace-nowrap shrink-0 hover:text-[#C5A059] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059] rounded-xs px-1 ${
                  isScrolled ? 'text-[#2D2A26]' : 'text-[#FAF9F6]'
                }`}
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Zone 3: Currency selector & actions */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Interactive Currency Selector */}
            <div
              className={`hidden sm:flex items-center p-0.5 rounded-sm border transition-colors ${
                isScrolled
                  ? 'bg-white border-[#DCD9D0] shadow-2xs'
                  : 'bg-black/40 border-white/20 backdrop-blur-sm'
              }`}
              role="group"
              aria-label="Select currency"
            >
              <Globe className={`w-3.5 h-3.5 mx-1.5 ${isScrolled ? 'text-[#8C651E]' : 'text-[#C5A059]'}`} />
              {currencies.map((curr) => (
                <button
                  key={curr.id}
                  onClick={() => onCurrencyChange(curr.id)}
                  className={`px-2 py-0.5 text-[11px] font-semibold rounded-xs transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059] ${
                    currency === curr.id
                      ? isScrolled
                        ? 'bg-[#1A1A1A] text-white shadow-xs'
                        : 'bg-[#C5A059] text-white'
                      : isScrolled
                      ? 'text-neutral-600 hover:text-black'
                      : 'text-neutral-300 hover:text-white'
                  }`}
                  aria-pressed={currency === curr.id}
                  aria-label={`Switch currency to ${curr.id}`}
                >
                  {curr.id}
                </button>
              ))}
            </div>

            {/* Direct Phone Call */}
            <a
              href={`tel:${HOTEL_INFO.phoneClean}`}
              className={`hidden md:flex items-center gap-1.5 text-xs tracking-wider uppercase transition-colors font-semibold px-2 py-1 rounded-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059] ${
                isScrolled ? 'text-[#2D2A26] hover:text-[#8C651E]' : 'text-white/90 hover:text-white'
              }`}
              title="Call Palace Reservations"
              aria-label={`Call Palace Reservations at ${HOTEL_INFO.phoneDisplay}`}
            >
              <Phone className="w-3.5 h-3.5 text-[#C5A059]" />
              <span className="whitespace-nowrap">{HOTEL_INFO.phoneDisplay}</span>
            </a>

            {/* Primary Action Button */}
            <button
              onClick={onBookNowClick}
              className="px-4 sm:px-5 py-2 text-xs font-semibold uppercase tracking-wider text-white bg-[#C5A059] hover:bg-[#a7823b] active:scale-[0.98] transition-all duration-200 rounded-sm shadow-sm flex items-center gap-1.5 whitespace-nowrap shrink-0 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059] focus-visible:ring-offset-2"
              aria-label="Book Now - Direct reservations"
            >
              <CalendarCheck className="w-4 h-4" />
              <span>Book Now</span>
            </button>

            {/* Mobile menu button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className={`xl:hidden p-2 rounded-sm transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059] ${
                isScrolled ? 'text-[#1A1A1A]' : 'text-white'
              }`}
              aria-label={mobileMenuOpen ? 'Close Navigation Menu' : 'Open Navigation Menu'}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile drawer */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-[#FAF9F6] border-b border-[#C5A059]/30 px-6 py-6 shadow-xl animate-in slide-in-from-top-4 duration-200">
          <div className="flex flex-col gap-3 text-base font-medium text-[#1A1A1A]">
            {/* Mobile Currency Converter */}
            <div className="pb-3 border-b border-[#E5E2D9] flex items-center justify-between">
              <span className="text-xs uppercase tracking-wider font-semibold text-neutral-600">Currency</span>
              <div className="flex items-center gap-1">
                {currencies.map((curr) => (
                  <button
                    key={curr.id}
                    onClick={() => onCurrencyChange(curr.id)}
                    className={`px-2.5 py-1 text-xs font-semibold rounded-sm border ${
                      currency === curr.id
                        ? 'bg-[#1A1A1A] text-white border-[#1A1A1A]'
                        : 'bg-white text-neutral-700 border-[#DCD9D0]'
                    }`}
                  >
                    {curr.id}
                  </button>
                ))}
              </div>
            </div>

            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="py-1.5 border-b border-[#E5E2D9] hover:text-[#8C651E] transition-colors text-sm"
              >
                {link.label}
              </a>
            ))}
            <div className="pt-2 flex flex-col gap-3">
              <a
                href={`tel:${HOTEL_INFO.phoneClean}`}
                className="flex items-center gap-2 text-sm text-[#333] py-1 font-semibold"
              >
                <Phone className="w-4 h-4 text-[#8C651E]" />
                <span>Call: {HOTEL_INFO.phoneDisplay}</span>
              </a>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onBookNowClick();
                }}
                className="w-full text-center py-3 bg-[#C5A059] text-white font-semibold text-sm uppercase tracking-wider rounded-sm shadow-sm hover:bg-[#a7823b]"
              >
                Book Now
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
