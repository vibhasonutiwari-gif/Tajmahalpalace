import React, { useRef } from 'react';
import { PRESS_AWARDS } from '../data/hotelData';
import { Award, ChevronLeft, ChevronRight, Star, ShieldCheck, Sparkles } from 'lucide-react';

export const PressAwardsStrip: React.FC = () => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const scrollAmount = direction === 'left' ? -340 : 340;
      scrollContainerRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  return (
    <section
      id="awards"
      aria-label="Authoritative Press and Hotel Awards"
      className="bg-[#F5F5F0] border-b border-[#E5E2D9] py-8 relative overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-[#1A1A1A] flex items-center justify-center text-[#C5A059] shrink-0">
              <Award className="w-4 h-4" />
            </div>
            <div>
              <p className="text-[11px] uppercase tracking-[0.2em] text-[#8C651E] font-semibold">
                Global Recognition &amp; Accolades
              </p>
              <h3 className="font-serif text-lg sm:text-xl font-bold text-[#1A1A1A]">
                Celebrated by the World’s Leading Authorities
              </h3>
            </div>
          </div>

          {/* Carousel Navigation Buttons with Keyboard Focus Rings */}
          <div className="flex items-center gap-2 self-end md:self-auto">
            <button
              onClick={() => scroll('left')}
              className="p-2 rounded-sm bg-white border border-[#DCD9D0] text-[#1A1A1A] hover:bg-[#FAF9F6] hover:border-[#C5A059] transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059] focus-visible:ring-offset-2"
              aria-label="Scroll awards carousel left"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => scroll('right')}
              className="p-2 rounded-sm bg-white border border-[#DCD9D0] text-[#1A1A1A] hover:bg-[#FAF9F6] hover:border-[#C5A059] transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059] focus-visible:ring-offset-2"
              aria-label="Scroll awards carousel right"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Horizontal Scrolling Awards Track */}
        <div
          ref={scrollContainerRef}
          className="flex items-stretch gap-5 overflow-x-auto scrollbar-none pb-2 pt-1 scroll-smooth"
          style={{ scrollSnapType: 'x mandatory' }}
          role="region"
          aria-label="Awards list carousel"
        >
          {PRESS_AWARDS.map((award) => (
            <div
              key={award.id}
              className="w-[280px] sm:w-[320px] shrink-0 bg-white border border-[#E5E2D9] rounded-sm p-5 flex flex-col justify-between shadow-xs hover:border-[#C5A059] hover:shadow-md transition-all duration-300"
              style={{ scrollSnapAlign: 'start' }}
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[11px] font-semibold text-[#8C651E] bg-[#FFFDD0]/70 px-2.5 py-0.5 rounded-sm border border-[#C5A059]/40">
                    {award.badge}
                  </span>
                  <span className="text-xs font-mono font-medium text-neutral-500">
                    {award.year}
                  </span>
                </div>

                <p className="text-xs uppercase tracking-wider font-semibold text-neutral-500 mb-1">
                  {award.organization}
                </p>

                <h4 className="font-serif text-base sm:text-lg font-bold text-[#1A1A1A] leading-snug">
                  {award.title}
                </h4>
              </div>

              <div className="pt-3 mt-3 border-t border-[#F0EDE6] flex items-center justify-between text-[11px] text-neutral-600">
                <span className="italic">{award.category}</span>
                <Sparkles className="w-3.5 h-3.5 text-[#C5A059]" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
