import React from 'react';
import { HOTEL_INFO } from '../data/hotelData';
import { Phone, MessageCircle } from 'lucide-react';

export const FloatingActions: React.FC = () => {
  const whatsappUrl = `https://wa.me/${HOTEL_INFO.phoneClean}?text=Hello%20Concierge%2C%20I%20would%20like%20to%20inquire%20about%20a%20luxury%20reservation%20at%20The%20Taj%20Mahal%20Palace%20Mumbai.`;

  return (
    <aside aria-label="Quick Contact Concierge" className="fixed bottom-6 right-6 z-40 flex flex-col gap-3">
      {/* WhatsApp Reservations */}
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="w-12 h-12 sm:w-auto sm:px-4 sm:py-2.5 rounded-full bg-[#1E7E34] hover:bg-[#155d27] text-white shadow-xl hover:shadow-2xl flex items-center justify-center gap-2 transition-all duration-300 transform hover:-translate-y-0.5 active:translate-y-0"
        title="Chat with Taj Concierge on WhatsApp"
        aria-label="Chat with Taj Concierge on WhatsApp"
      >
        <MessageCircle className="w-5 h-5" />
        <span className="hidden sm:inline text-xs font-semibold tracking-wide">
          WhatsApp Reservations
        </span>
      </a>

      {/* Call Now */}
      <a
        href={`tel:${HOTEL_INFO.phoneClean}`}
        className="w-12 h-12 sm:w-auto sm:px-4 sm:py-2.5 rounded-full bg-[#1A1A1A] hover:bg-[#C5A059] text-white shadow-xl hover:shadow-2xl flex items-center justify-center gap-2 transition-all duration-300 transform hover:-translate-y-0.5 active:translate-y-0 border border-[#C5A059]/40"
        title={`Call Taj Palace Concierge at ${HOTEL_INFO.phoneDisplay}`}
        aria-label={`Call Taj Palace Concierge at ${HOTEL_INFO.phoneDisplay}`}
      >
        <Phone className="w-4 h-4 text-[#C5A059]" />
        <span className="hidden sm:inline text-xs font-semibold tracking-wide">
          Call: +91 22 6665 3366
        </span>
      </a>
    </aside>
  );
};
