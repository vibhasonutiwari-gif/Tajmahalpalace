import React, { useState } from 'react';
import { CONCIERGE_FAQS, HOTEL_INFO } from '../data/hotelData';
import { ChevronDown, HelpCircle, Phone, MessageCircle, Sparkles } from 'lucide-react';

export const ConciergeFAQ: React.FC = () => {
  const [openId, setOpenId] = useState<string | null>('faq-1');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = ['All', 'Check-in & Stays', 'Dining & Dress Code', 'Airport & Location', 'Policies & Concierge'];

  const filteredFaqs = CONCIERGE_FAQS.filter((faq) => {
    if (selectedCategory === 'All') return true;
    return faq.category === selectedCategory;
  });

  const toggleFaq = (id: string) => {
    setOpenId((prev) => (prev === id ? null : id));
  };

  return (
    <section id="faq" className="py-24 bg-[#FAF9F6] border-b border-[#E8E6DF]" aria-labelledby="faq-title">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <p className="text-xs uppercase tracking-[0.25em] text-[#8C651E] font-semibold mb-2">
            Palace Concierge Desk
          </p>
          <h2 id="faq-title" className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-[#1A1A1A] leading-tight text-balance">
            Frequently Asked Guest Questions
          </h2>
          <div className="w-16 h-0.5 bg-[#C5A059] mx-auto mt-4 mb-4" />
          <p className="text-neutral-700 text-sm sm:text-base font-light">
            Essential guidelines regarding check-in hospitality, fine dining dress codes, Rolls-Royce limousine transfers, and stay policies.
          </p>
        </div>

        {/* Category Filter Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-10" role="tablist" aria-label="FAQ Categories">
          {categories.map((cat) => (
            <button
              key={cat}
              role="tab"
              aria-selected={selectedCategory === cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 text-xs font-semibold rounded-sm transition-colors border focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059] focus-visible:ring-offset-2 ${
                selectedCategory === cat
                  ? 'bg-[#1A1A1A] text-white border-[#1A1A1A] shadow-sm'
                  : 'bg-white text-neutral-700 border-[#E0DDD5] hover:border-[#C5A059] hover:text-[#1A1A1A]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Expandable Accordion with Keyboard Focus Rings */}
        <div className="space-y-4">
          {filteredFaqs.map((faq) => {
            const isOpen = openId === faq.id;
            return (
              <div
                key={faq.id}
                className="bg-white border border-[#E5E2D9] rounded-sm transition-all duration-200 overflow-hidden shadow-xs hover:border-[#C5A059]/60"
              >
                <button
                  type="button"
                  onClick={() => toggleFaq(faq.id)}
                  aria-expanded={isOpen}
                  aria-controls={`faq-answer-${faq.id}`}
                  className="w-full text-left p-5 sm:p-6 flex items-center justify-between gap-4 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059] focus-visible:ring-offset-2"
                >
                  <div className="flex items-start gap-3">
                    <span className="text-xs uppercase tracking-wider font-semibold text-[#8C651E] bg-[#FFFDD0] px-2 py-0.5 rounded-sm border border-[#C5A059]/30 shrink-0 mt-0.5">
                      {faq.category}
                    </span>
                    <h3 className="font-serif text-base sm:text-lg font-bold text-[#1A1A1A]">
                      {faq.question}
                    </h3>
                  </div>

                  <div className={`w-8 h-8 rounded-full bg-[#FAF9F6] border border-[#E0DDD5] flex items-center justify-center text-[#8C651E] shrink-0 transition-transform duration-200 ${isOpen ? 'rotate-180 bg-[#C5A059] text-white' : ''}`}>
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div
                    id={`faq-answer-${faq.id}`}
                    role="region"
                    className="px-5 sm:px-6 pb-6 pt-1 text-xs sm:text-sm text-neutral-700 leading-relaxed font-light border-t border-[#F5F2EB] animate-in fade-in duration-200"
                  >
                    <p>{faq.answer}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Concierge Desk Support Banner */}
        <div className="mt-12 p-6 bg-[#F5F5F0] border border-[#C5A059]/40 rounded-sm flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-white border border-[#C5A059] flex items-center justify-center text-[#8C651E] shrink-0">
              <HelpCircle className="w-5 h-5" />
            </div>
            <div>
              <p className="font-serif font-bold text-base text-[#1A1A1A]">
                Have a bespoke reservation inquiry or custom request?
              </p>
              <p className="text-xs text-neutral-600 mt-0.5">
                Our Chief Concierge and Palace Butler retinue are on duty 24/7 to assist.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <a
              href={`tel:${HOTEL_INFO.phoneClean}`}
              className="flex-1 sm:flex-initial px-4 py-2.5 bg-[#1A1A1A] hover:bg-[#C5A059] text-white text-xs font-semibold uppercase tracking-wider rounded-sm transition-colors text-center flex items-center justify-center gap-1.5 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059] focus-visible:ring-offset-2"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>Call Concierge</span>
            </a>
            <a
              href={`https://wa.me/${HOTEL_INFO.phoneClean}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 sm:flex-initial px-4 py-2.5 bg-[#1E7E34] hover:bg-[#155d27] text-white text-xs font-semibold uppercase tracking-wider rounded-sm transition-colors text-center flex items-center justify-center gap-1.5 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059] focus-visible:ring-offset-2"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>WhatsApp</span>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};
