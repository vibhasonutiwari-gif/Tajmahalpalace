import React from 'react';
import { ReservationData } from '../types/hotel';
import { HOTEL_INFO } from '../data/hotelData';
import { CheckCircle, Calendar, Users, Hotel, Phone, Mail, X, MessageCircle, Download } from 'lucide-react';

interface ReservationModalProps {
  reservation: ReservationData;
  onClose: () => void;
}

export const ReservationModal: React.FC<ReservationModalProps> = ({ reservation, onClose }) => {
  const whatsappMessage = `Hello Concierge, I just submitted reservation inquiry *${reservation.id}* for ${reservation.suitePreference} at The Taj Mahal Palace Mumbai. Guest name: ${reservation.fullName}.`;
  const whatsappUrl = `https://wa.me/${HOTEL_INFO.phoneClean}?text=${encodeURIComponent(whatsappMessage)}`;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200"
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
    >
      <div className="bg-[#FAF9F6] border border-[#C5A059] rounded-sm max-w-xl w-full shadow-2xl overflow-hidden relative animate-in zoom-in-95 duration-200">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 w-8 h-8 rounded-full bg-[#F5F5F0] hover:bg-[#EAE8E1] text-[#1A1A1A] flex items-center justify-center transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059]"
          aria-label="Close Confirmation Dialog"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header Ribbon */}
        <div className="bg-[#1A1A1A] p-6 text-white text-center border-b border-[#C5A059]">
          <div className="w-12 h-12 rounded-full bg-[#C5A059]/20 border border-[#C5A059] flex items-center justify-center mx-auto mb-3">
            <CheckCircle className="w-6 h-6 text-[#C5A059]" />
          </div>
          <p className="text-[11px] uppercase tracking-[0.25em] text-[#C5A059] font-semibold">
            The Taj Mahal Palace, Mumbai
          </p>
          <h3 id="modal-title" className="font-serif text-2xl font-bold mt-1">
            Reservation Inquiry Submitted
          </h3>
          <p className="text-xs text-neutral-300 mt-1 font-mono tracking-wider">
            Reference No: <span className="text-[#E8D3A2] font-bold">{reservation.id}</span>
          </p>
        </div>

        {/* Modal Body with exact requested text */}
        <div className="p-6 sm:p-8 space-y-6">
          {/* Exact Required Master Prompt Sentence */}
          <div className="p-4 bg-[#FFFDD0]/40 border-l-4 border-[#C5A059] rounded-r-sm">
            <p className="text-sm text-[#1A1A1A] font-medium leading-relaxed">
              Thank you! Your reservation request has been submitted. Our concierge team at The Taj Mahal Palace will contact you via phone or email shortly to confirm your booking.
            </p>
          </div>

          {/* Reservation Summary */}
          <div className="bg-[#F5F5F0] p-4 rounded-sm border border-[#E5E2D9] space-y-3 text-xs sm:text-sm">
            <div className="flex items-center justify-between pb-2 border-b border-[#E0DDD5]">
              <span className="text-neutral-500 flex items-center gap-1.5">
                <Hotel className="w-3.5 h-3.5 text-[#C5A059]" /> Suite Category:
              </span>
              <span className="font-serif font-bold text-[#1A1A1A]">{reservation.suitePreference}</span>
            </div>

            <div className="flex items-center justify-between pb-2 border-b border-[#E0DDD5]">
              <span className="text-neutral-500 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-[#C5A059]" /> Dates of Stay:
              </span>
              <span className="font-medium text-[#1A1A1A]">{reservation.checkIn} → {reservation.checkOut}</span>
            </div>

            <div className="flex items-center justify-between pb-2 border-b border-[#E0DDD5]">
              <span className="text-neutral-500 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-[#C5A059]" /> Occupancy:
              </span>
              <span className="font-medium text-[#1A1A1A]">{reservation.adults} Adults, {reservation.children} Children</span>
            </div>

            <div className="flex items-center justify-between pb-2 border-b border-[#E0DDD5]">
              <span className="text-neutral-500 flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-[#C5A059]" /> Guest:
              </span>
              <span className="font-medium text-[#1A1A1A]">{reservation.fullName} ({reservation.phone})</span>
            </div>

            {reservation.estimatedFormattedTotal && (
              <div className="flex items-center justify-between pb-2 border-b border-[#E0DDD5]">
                <span className="text-neutral-500 flex items-center gap-1.5">
                  <span className="text-[#C5A059] font-bold">★</span> Estimated Total:
                </span>
                <span className="font-serif font-bold text-base text-[#1A1A1A]">
                  {reservation.estimatedFormattedTotal} <span className="text-xs font-sans font-normal text-neutral-500">({reservation.currency})</span>
                </span>
              </div>
            )}

            {reservation.specialRequests && (
              <div className="pt-1">
                <span className="text-neutral-500 block text-[11px] uppercase tracking-wider mb-0.5">Special Requests:</span>
                <p className="text-neutral-700 italic text-xs">{reservation.specialRequests}</p>
              </div>
            )}
          </div>

          {/* Action CTAs */}
          <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:flex-1 py-3 px-4 bg-[#1E7E34] hover:bg-[#155d27] text-white text-xs font-semibold uppercase tracking-wider rounded-sm transition-colors text-center flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Connect on WhatsApp</span>
            </a>

            <button
              onClick={handlePrint}
              className="w-full sm:w-auto py-3 px-4 bg-white border border-[#C5A059] hover:bg-[#FAF9F6] text-[#1A1A1A] text-xs font-semibold uppercase tracking-wider rounded-sm transition-colors flex items-center justify-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5 text-[#C5A059]" />
              <span>Save / Print</span>
            </button>

            <button
              onClick={onClose}
              className="w-full sm:w-auto py-3 px-5 bg-[#1A1A1A] hover:bg-[#333] text-white text-xs font-semibold uppercase tracking-wider rounded-sm transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
