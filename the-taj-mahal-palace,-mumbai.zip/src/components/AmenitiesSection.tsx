import React from 'react';
import { AMENITIES, HOTEL_REAL_IMAGES } from '../data/hotelData';
import {
  Sparkles,
  UserCheck,
  Waves,
  Activity,
  Award,
  ShoppingBag,
  UtensilsCrossed,
  Car,
  Clock
} from 'lucide-react';

export const AmenitiesSection: React.FC = () => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Sparkles':
        return <Sparkles className="w-5 h-5 text-[#8C651E]" />;
      case 'UserCheck':
        return <UserCheck className="w-5 h-5 text-[#8C651E]" />;
      case 'Waves':
        return <Waves className="w-5 h-5 text-[#8C651E]" />;
      case 'Activity':
        return <Activity className="w-5 h-5 text-[#8C651E]" />;
      case 'Award':
        return <Award className="w-5 h-5 text-[#8C651E]" />;
      case 'ShoppingBag':
        return <ShoppingBag className="w-5 h-5 text-[#8C651E]" />;
      case 'UtensilsCrossed':
        return <UtensilsCrossed className="w-5 h-5 text-[#8C651E]" />;
      case 'Car':
        return <Car className="w-5 h-5 text-[#8C651E]" />;
      default:
        return <Sparkles className="w-5 h-5 text-[#8C651E]" />;
    }
  };

  return (
    <section id="facilities" className="py-24 bg-[#F5F5F0] border-b border-[#E5E2D9]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <p className="text-xs uppercase tracking-[0.25em] text-[#8C651E] font-semibold mb-2">
            Legendary Privileges &amp; Leisure
          </p>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-[#1A1A1A] leading-tight text-balance">
            Facilities &amp; Iconic Hotel Amenities
          </h2>
          <div className="w-16 h-0.5 bg-[#C5A059] mx-auto mt-4 mb-4" />
          <p className="text-neutral-700 text-sm sm:text-base font-light">
            Every convenience curated for the regal traveler, from authentic Ayurvedic therapies at Jiva Spa to round-the-clock palace butler retinue.
          </p>
        </div>

        {/* Feature Banner: Landscaped Outdoor Pool & Courtyard */}
        <div className="mb-14 rounded-sm overflow-hidden border border-[#E0DDD5] shadow-lg relative bg-neutral-900">
          <div className="relative h-80 sm:h-96 w-full">
            <img
              src={HOTEL_REAL_IMAGES.poolCourtyard}
              alt="Landscaped Outdoor Courtyard Pool at The Taj Mahal Palace, Mumbai"
              className="w-full h-full object-cover"
              loading="lazy"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/35 to-transparent" />
            <div className="absolute bottom-6 left-6 right-6 text-white max-w-3xl">
              <span className="text-xs uppercase tracking-widest text-[#E8D3A2] font-semibold flex items-center gap-1.5 mb-1.5">
                <Waves className="w-3.5 h-3.5 text-[#C5A059]" />
                Historic Courtyard Oasis
              </span>
              <h3 className="font-serif text-2xl sm:text-3xl md:text-4xl font-bold">
                The Palace Swimming Pool &amp; Colonnade
              </h3>
              <p className="text-xs sm:text-sm text-neutral-200 mt-2 font-light leading-relaxed">
                Framed by century-old stone arches, soaring royal palm trees, and fragrant frangipani blossoms. A tranquil private sanctuary set secluded amidst the vibrant heartbeat of Mumbai.
              </p>
            </div>
          </div>
        </div>

        {/* 8 Amenities Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {AMENITIES.map((amenity) => (
            <div
              key={amenity.id}
              className="p-6 bg-[#FAF9F6] border border-[#E5E2D9] rounded-sm flex flex-col justify-between hover:border-[#C5A059] hover:shadow-md transition-all duration-300 group"
            >
              <div>
                <div className="w-11 h-11 rounded-sm bg-white border border-[#E0DDD5] group-hover:border-[#C5A059] flex items-center justify-center mb-4 transition-colors">
                  {getIcon(amenity.iconName)}
                </div>

                <h3 className="font-serif text-lg font-bold text-[#1A1A1A] group-hover:text-[#8C651E] transition-colors">
                  {amenity.title}
                </h3>

                <p className="text-xs text-[#8C651E] font-semibold mt-1 mb-2">
                  {amenity.tagline}
                </p>

                <p className="text-xs sm:text-sm text-neutral-700 leading-relaxed font-light">
                  {amenity.description}
                </p>
              </div>

              {amenity.hours && (
                <div className="mt-5 pt-3 border-t border-[#E8E6DF] flex items-center gap-1.5 text-[11px] text-neutral-600 font-medium">
                  <Clock className="w-3 h-3 text-[#8C651E]" />
                  <span>{amenity.hours}</span>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
