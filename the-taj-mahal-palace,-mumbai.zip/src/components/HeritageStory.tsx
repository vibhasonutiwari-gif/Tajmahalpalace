import React from 'react';
import { HOTEL_REAL_IMAGES } from '../data/hotelData';
import { History } from 'lucide-react';

export const HeritageStory: React.FC = () => {
  return (
    <section id="heritage" className="py-20 lg:py-28 bg-[#FAF9F6] border-b border-[#E8E6DF]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Editorial Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <p className="text-xs uppercase tracking-[0.25em] text-[#8C651E] font-semibold mb-3">
            A Living Monument Since 1903
          </p>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-[#1A1A1A] leading-tight text-balance">
            Where India Welcomes the World in Palatial Splendor
          </h2>
          <div className="w-16 h-0.5 bg-[#C5A059] mx-auto mt-5 mb-5" />
          <p className="text-neutral-700 text-base sm:text-lg leading-relaxed font-light">
            Commissioned by pioneer visionary Jamsetji Nusserwanji Tata, The Taj Mahal Palace opened its grand doors in 1903—even before the Gateway of India stood on Mumbai’s shores.
          </p>
        </div>

        {/* 2-Column Split: Visual Narrative & Historical Pillars */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Visual Showcase with Arch Framing */}
          <div className="lg:col-span-6 relative">
            <div className="relative rounded-sm overflow-hidden shadow-xl border border-[#E5E2D9]">
              <img
                src={HOTEL_REAL_IMAGES.facadeFrontal}
                alt="Architectural heritage of The Taj Mahal Palace Mumbai at Apollo Bunder"
                className="w-full h-[420px] sm:h-[480px] object-cover"
                loading="lazy"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent" />
              <div className="absolute bottom-6 left-6 right-6 text-white">
                <p className="font-serif text-xl sm:text-2xl font-bold drop-shadow-md">
                  The 240-Foot Red Dome
                </p>
                <p className="text-xs sm:text-sm text-neutral-100 mt-1">
                  Mumbai Harbour's historical maritime beacon and symbol of Indian resilience.
                </p>
              </div>
            </div>

            {/* Inset Decorative Heritage Seal */}
            <div className="hidden sm:flex absolute -bottom-6 -right-6 bg-white p-4 rounded-sm border border-[#C5A059]/50 shadow-xl items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-[#FAF9F6] border border-[#C5A059] flex items-center justify-center">
                <History className="w-6 h-6 text-[#8C651E]" />
              </div>
              <div>
                <p className="text-xs uppercase tracking-wider text-neutral-600 font-semibold">Historic First</p>
                <p className="font-serif text-base font-bold text-[#1A1A1A]">India's 1st Luxury Hotel</p>
              </div>
            </div>
          </div>

          {/* Right Column: Architectural Highlights */}
          <div className="lg:col-span-6 space-y-6">
            <div className="space-y-4">
              <h3 className="font-serif text-2xl sm:text-3xl font-semibold text-[#1A1A1A]">
                The Jewel of Apollo Bunder
              </h3>
              <p className="text-neutral-700 leading-relaxed text-sm sm:text-base">
                For over a century, The Taj Mahal Palace has welcomed maharajas, heads of state, artists, and luminaries from around the globe. Its distinctive architectural harmony seamlessly weaves Moorish, Oriental, and Florentine styles with intricate Indian craftsmanship.
              </p>
              <p className="text-neutral-700 leading-relaxed text-sm sm:text-base">
                From the vaulted ceilings adorned with Belgian crystal chandeliers to the cantilevered floating staircases, every stone and corridor whispers tales of royal galas, historic summits, and celebrated romance over Mumbai’s Arabian Sea.
              </p>
            </div>

            {/* 4 Architectural Milestones / Stats */}
            <div className="grid grid-cols-2 gap-4 pt-4 border-t border-[#E8E6DF]">
              <div className="p-4 bg-white rounded-sm border border-[#E5E2D9]">
                <p className="font-serif text-2xl sm:text-3xl font-bold text-[#8C651E] tabular-nums">1903</p>
                <p className="text-xs uppercase tracking-wider text-neutral-700 mt-1 font-semibold">Inaugural Year</p>
              </div>
              <div className="p-4 bg-white rounded-sm border border-[#E5E2D9]">
                <p className="font-serif text-2xl sm:text-3xl font-bold text-[#8C651E] tabular-nums">285+</p>
                <p className="text-xs uppercase tracking-wider text-neutral-700 mt-1 font-semibold">Palatial Rooms &amp; Suites</p>
              </div>
              <div className="p-4 bg-white rounded-sm border border-[#E5E2D9]">
                <p className="font-serif text-2xl sm:text-3xl font-bold text-[#8C651E] tabular-nums">10</p>
                <p className="text-xs uppercase tracking-wider text-neutral-700 mt-1 font-semibold">Iconic Dining Venues</p>
              </div>
              <div className="p-4 bg-white rounded-sm border border-[#E5E2D9]">
                <p className="font-serif text-2xl sm:text-3xl font-bold text-[#8C651E] tabular-nums">44+</p>
                <p className="text-xs uppercase tracking-wider text-neutral-700 mt-1 font-semibold">Handcrafted Chandeliers</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
