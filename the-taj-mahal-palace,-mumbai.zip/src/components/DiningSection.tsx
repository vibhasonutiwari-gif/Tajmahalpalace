import React, { useState, useMemo } from 'react';
import { DISHES, formatCurrency } from '../data/hotelData';
import { Currency } from '../types/hotel';
import { ChefHat, Utensils, Search, X, Sparkles, SlidersHorizontal } from 'lucide-react';

interface DiningSectionProps {
  onDishSelect: (dishName: string) => void;
  currency?: Currency;
  onCurrencyChange?: (currency: Currency) => void;
}

export const DiningSection: React.FC<DiningSectionProps> = ({
  onDishSelect,
  currency = 'INR',
  onCurrencyChange,
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'indian' | 'international'>('all');
  const [localCurrency, setLocalCurrency] = useState<Currency>(currency);
  const [dietaryFilter, setDietaryFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const activeCurrency = onCurrencyChange ? currency : localCurrency;
  const handleCurrencyToggle = (c: Currency) => {
    if (onCurrencyChange) {
      onCurrencyChange(c);
    } else {
      setLocalCurrency(c);
    }
  };

  const currencies: Currency[] = ['INR', 'USD', 'EUR', 'GBP'];

  const quickSearchTags = ['Lobster', 'Biryani', 'Sushi', 'Truffle', 'Wasabi', 'Vegetarian'];

  const filteredDishes = useMemo(() => {
    return DISHES.filter((dish) => {
      // Cuisine tab match
      const matchesTab = activeTab === 'all' || dish.cuisineTab === activeTab;

      // Dietary filter match
      const matchesDietary =
        dietaryFilter === 'all' ||
        (dietaryFilter === 'veg' && (dish.dietary === 'Vegetarian' || dish.dietary === 'Dessert')) ||
        (dietaryFilter === 'non-veg' && dish.dietary === 'Non-Vegetarian') ||
        (dietaryFilter === 'seafood' && dish.dietary === 'Seafood');

      // Search query filter match across name, description, tags, restaurant
      const query = searchQuery.trim().toLowerCase();
      const matchesSearch =
        !query ||
        dish.name.toLowerCase().includes(query) ||
        dish.tagline.toLowerCase().includes(query) ||
        dish.description.toLowerCase().includes(query) ||
        dish.restaurant.toLowerCase().includes(query) ||
        dish.dietary.toLowerCase().includes(query) ||
        dish.tags.some((tag) => tag.toLowerCase().includes(query));

      return matchesTab && matchesDietary && matchesSearch;
    });
  }, [activeTab, dietaryFilter, searchQuery]);

  return (
    <section id="dining" className="py-24 bg-[#FAF9F6] border-b border-[#E8E6DF]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <p className="text-xs uppercase tracking-[0.25em] text-[#8C651E] font-semibold mb-2">
            Haute Gastronomy &amp; Culinary Heritage
          </p>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-[#1A1A1A] leading-tight text-balance">
            Fine Dining at The Taj Mahal Palace
          </h2>
          <div className="w-16 h-0.5 bg-[#C5A059] mx-auto mt-4 mb-4" />
          <p className="text-neutral-700 text-sm sm:text-base font-light">
            Home to iconic culinary destinations: <span className="font-semibold text-[#1A1A1A]">Wasabi by Morimoto</span>, <span className="font-semibold text-[#1A1A1A]">Golden Dragon</span>, <span className="font-semibold text-[#1A1A1A]">Shamiana</span>, <span className="font-semibold text-[#1A1A1A]">Sea Lounge</span>, and India’s first licensed venue, <span className="font-semibold text-[#1A1A1A]">Harbour Bar</span>.
          </p>
        </div>

        {/* Filterable Menu Search Bar & Currency Control */}
        <div className="bg-white border border-[#E5E2D9] rounded-sm p-4 sm:p-5 shadow-xs mb-8">
          <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4">
            {/* Instant Search Input */}
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search dishes by name, ingredient, or style (e.g. Lobster, Biryani, Sushi, Truffle)..."
                className="w-full pl-10 pr-9 py-2.5 bg-[#FAF9F6] border border-[#DCD9D0] rounded-sm text-xs sm:text-sm text-[#1A1A1A] placeholder-neutral-400 focus:outline-none focus:border-[#C5A059] focus-visible:ring-2 focus-visible:ring-[#C5A059] transition-all"
                aria-label="Search dishes and ingredients"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-black focus:outline-none focus-visible:ring-1 focus-visible:ring-[#C5A059]"
                  aria-label="Clear search input"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Quick Currency Selector */}
            <div className="flex items-center gap-1.5 self-end lg:self-auto shrink-0 bg-[#F5F5F0] p-1 rounded-sm border border-[#E0DDD5]">
              <span className="text-[11px] text-neutral-600 px-1 font-medium hidden sm:inline">Price:</span>
              {currencies.map((curr) => (
                <button
                  key={curr}
                  onClick={() => handleCurrencyToggle(curr)}
                  className={`px-2.5 py-1 text-xs font-semibold rounded-xs transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059] ${
                    activeCurrency === curr
                      ? 'bg-[#C5A059] text-white shadow-xs'
                      : 'text-neutral-700 hover:text-black'
                  }`}
                  aria-label={`Toggle dining prices to ${curr}`}
                >
                  {curr === 'INR' ? '₹ INR' : curr === 'USD' ? '$ USD' : curr === 'EUR' ? '€ EUR' : '£ GBP'}
                </button>
              ))}
            </div>
          </div>

          {/* Quick Search Suggestion Chips */}
          <div className="flex flex-wrap items-center gap-2 mt-3 pt-3 border-t border-[#F0EDE6] text-xs">
            <span className="text-neutral-500 font-medium text-[11px] uppercase tracking-wider flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-[#C5A059]" /> Popular:
            </span>
            {quickSearchTags.map((tag) => (
              <button
                key={tag}
                onClick={() => setSearchQuery(tag)}
                className={`px-2.5 py-1 text-xs rounded-sm transition-colors border focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059] ${
                  searchQuery.toLowerCase() === tag.toLowerCase()
                    ? 'bg-[#1A1A1A] text-white border-[#1A1A1A]'
                    : 'bg-[#FAF9F6] text-neutral-700 border-[#E0DDD5] hover:border-[#C5A059] hover:text-[#1A1A1A]'
                }`}
              >
                {tag}
              </button>
            ))}
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="text-[11px] text-[#8C651E] font-semibold underline underline-offset-2 ml-auto"
              >
                Reset Search
              </button>
            )}
          </div>
        </div>

        {/* Tab Switcher & Dietary Filters */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-10 pb-6 border-b border-[#E8E6DF]">
          {/* Main Cuisine Tabs */}
          <div className="flex items-center p-1 bg-[#F5F5F0] rounded-sm border border-[#E0DDD5] w-full sm:w-auto" role="tablist">
            <button
              role="tab"
              aria-selected={activeTab === 'all'}
              onClick={() => setActiveTab('all')}
              className={`flex-1 sm:flex-initial px-4 py-2 text-xs font-semibold rounded-xs transition-all duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059] ${
                activeTab === 'all'
                  ? 'bg-[#1A1A1A] text-white shadow-xs'
                  : 'text-neutral-700 hover:text-[#1A1A1A]'
              }`}
            >
              All Menu
            </button>
            <button
              role="tab"
              aria-selected={activeTab === 'indian'}
              onClick={() => setActiveTab('indian')}
              className={`flex-1 sm:flex-initial px-4 py-2 text-xs font-semibold rounded-xs transition-all duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059] ${
                activeTab === 'indian'
                  ? 'bg-[#1A1A1A] text-white shadow-xs'
                  : 'text-neutral-700 hover:text-[#1A1A1A]'
              }`}
            >
              Indian &amp; Regional
            </button>
            <button
              role="tab"
              aria-selected={activeTab === 'international'}
              onClick={() => setActiveTab('international')}
              className={`flex-1 sm:flex-initial px-4 py-2 text-xs font-semibold rounded-xs transition-all duration-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059] ${
                activeTab === 'international'
                  ? 'bg-[#1A1A1A] text-white shadow-xs'
                  : 'text-neutral-700 hover:text-[#1A1A1A]'
              }`}
            >
              International Classics
            </button>
          </div>

          {/* Sub Dietary Filter */}
          <div className="flex items-center gap-1.5 text-xs w-full sm:w-auto justify-end" role="group" aria-label="Filter dishes by dietary preference">
            <span className="text-[11px] text-neutral-500 font-medium uppercase tracking-wider mr-1 hidden md:inline">Dietary:</span>
            <button
              onClick={() => setDietaryFilter('all')}
              className={`px-3 py-1.5 rounded-sm transition-colors font-medium border focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059] ${
                dietaryFilter === 'all'
                  ? 'bg-[#1A1A1A] text-white border-[#1A1A1A]'
                  : 'text-neutral-700 bg-white border-[#E0DDD5] hover:bg-[#FAF9F6]'
              }`}
              aria-label="Show all dietary options"
            >
              All
            </button>
            <button
              onClick={() => setDietaryFilter('veg')}
              className={`px-3 py-1.5 rounded-sm transition-colors font-medium border focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059] ${
                dietaryFilter === 'veg'
                  ? 'bg-[#1A1A1A] text-white border-[#1A1A1A]'
                  : 'text-neutral-700 bg-white border-[#E0DDD5] hover:bg-[#FAF9F6]'
              }`}
              aria-label="Filter vegetarian dishes"
            >
              Vegetarian
            </button>
            <button
              onClick={() => setDietaryFilter('non-veg')}
              className={`px-3 py-1.5 rounded-sm transition-colors font-medium border focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059] ${
                dietaryFilter === 'non-veg'
                  ? 'bg-[#1A1A1A] text-white border-[#1A1A1A]'
                  : 'text-neutral-700 bg-white border-[#E0DDD5] hover:bg-[#FAF9F6]'
              }`}
              aria-label="Filter non-vegetarian dishes"
            >
              Non-Veg
            </button>
          </div>
        </div>

        {/* Dish Showcase Cards Grid */}
        {filteredDishes.length === 0 ? (
          <div className="p-12 text-center bg-white border border-[#E5E2D9] rounded-sm">
            <Utensils className="w-10 h-10 text-[#C5A059] mx-auto mb-3" />
            <h3 className="font-serif text-xl font-bold text-[#1A1A1A]">No culinary items match your search</h3>
            <p className="text-xs text-neutral-600 mt-1 max-w-md mx-auto">
              Try searching for signature delicacies such as "Biryani", "Lobster", "Wasabi", or reset your dietary filters.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setDietaryFilter('all');
                setActiveTab('all');
              }}
              className="mt-4 px-4 py-2 bg-[#C5A059] text-white text-xs font-semibold rounded-sm hover:bg-[#a7823b] transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059]"
            >
              Reset All Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredDishes.map((dish) => {
              const formattedPrice = formatCurrency(dish.priceINR, activeCurrency);

              return (
                <div
                  key={dish.id}
                  className="bg-white border border-[#E8E6DF] rounded-sm overflow-hidden flex flex-col group hover:border-[#C5A059] hover:shadow-lg transition-all duration-300"
                >
                  {/* Dedicated Dish Culinary Photo Container with 4:3 aspect ratio */}
                  <div className="relative aspect-[4/3] overflow-hidden bg-neutral-900">
                    <img
                      src={dish.image}
                      alt={`${dish.name} - ${dish.restaurant} at The Taj Mahal Palace`}
                      width="600"
                      height="450"
                      loading="lazy"
                      decoding="async"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />

                    {/* Top Badges */}
                    <div className="absolute top-3 left-3 right-3 flex items-center justify-between text-xs">
                      <span className="px-2.5 py-1 bg-black/80 backdrop-blur-md text-[#E8D3A2] rounded-xs font-semibold border border-white/15">
                        {dish.restaurant}
                      </span>
                      <span
                        className={`px-2.5 py-0.5 rounded-xs text-[11px] font-bold tracking-wide ${
                          dish.dietary === 'Vegetarian' || dish.dietary === 'Dessert'
                            ? 'bg-emerald-950/90 text-emerald-200 border border-emerald-400/40'
                            : dish.dietary === 'Seafood'
                            ? 'bg-sky-950/90 text-sky-200 border border-sky-400/40'
                            : 'bg-amber-950/90 text-amber-200 border border-amber-400/40'
                        }`}
                      >
                        {dish.dietary}
                      </span>
                    </div>

                    {/* Title on image */}
                    <div className="absolute bottom-3 left-3 right-3 text-white">
                      <h3 className="font-serif text-xl font-bold leading-tight drop-shadow-sm">{dish.name}</h3>
                    </div>
                  </div>

                  {/* Dish Details */}
                  <div className="p-5 flex-1 flex flex-col justify-between">
                    <div>
                      {/* Tagline */}
                      <p className="text-xs text-[#8C651E] font-semibold uppercase tracking-wider mb-2">
                        {dish.tagline}
                      </p>

                      {/* Description */}
                      <p className="text-xs sm:text-sm text-neutral-700 leading-relaxed mb-4">
                        {dish.description}
                      </p>

                      {/* Chef Note */}
                      {dish.chefNote && (
                        <div className="p-2.5 bg-[#FAF9F6] border-l-2 border-[#C5A059] rounded-r-xs text-[11px] text-neutral-800 italic flex items-start gap-1.5 mb-4">
                          <ChefHat className="w-3.5 h-3.5 text-[#8C651E] shrink-0 mt-0.5" />
                          <span>{dish.chefNote}</span>
                        </div>
                      )}
                    </div>

                    {/* Bottom Footer: Price & Quick Action */}
                    <div className="pt-3 border-t border-[#EFECE6] flex items-center justify-between">
                      <div>
                        <span className="text-[11px] text-neutral-500 uppercase tracking-wider font-medium">Price</span>
                        <p className="font-serif text-lg font-bold text-[#1A1A1A] tabular-nums">
                          {formattedPrice}
                        </p>
                      </div>

                      <button
                        onClick={() => onDishSelect(dish.name)}
                        className="px-3.5 py-1.5 text-xs font-semibold text-[#1A1A1A] hover:text-white bg-[#F5F5F0] hover:bg-[#C5A059] rounded-sm transition-colors border border-[#E0DDD5] hover:border-[#C5A059] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059] focus-visible:ring-offset-2"
                        aria-label={`Add inquiry for ${dish.name} to booking note`}
                      >
                        Add to Dining Note
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Heritage Dining Callout */}
        <div className="mt-16 p-8 bg-[#F5F5F0] border border-[#C5A059]/40 rounded-sm flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-[#FAF9F6] border border-[#C5A059] flex items-center justify-center shrink-0">
              <Utensils className="w-6 h-6 text-[#8C651E]" />
            </div>
            <div>
              <h4 className="font-serif text-xl font-bold text-[#1A1A1A]">
                Private Palace Dining &amp; Sommelier Pairings
              </h4>
              <p className="text-xs sm:text-sm text-neutral-700 mt-0.5">
                Table reservations at Wasabi by Morimoto, Shamiana, and Sea Lounge are prioritized for resident suite guests.
              </p>
            </div>
          </div>
          <a
            href="tel:+912266653366"
            className="px-6 py-2.5 text-xs font-semibold uppercase tracking-wider bg-[#1A1A1A] hover:bg-[#C5A059] text-white rounded-sm transition-colors whitespace-nowrap shadow-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059] focus-visible:ring-offset-2"
            aria-label="Call concierge for dining reservations at +91 22 6665 3366"
          >
            Call Concierge: +91 22 6665 3366
          </a>
        </div>
      </div>
    </section>
  );
};
