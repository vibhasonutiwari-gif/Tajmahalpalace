import React from 'react';
import { HOTEL_INFO } from '../data/hotelData';
import { MapPin, Phone, Mail, Globe, ArrowUp, Sparkles } from 'lucide-react';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const brands = [
    'Taj',
    'Claridges',
    'Atmantan',
    'Brij',
    'SeleQtions',
    'Clarks',
    'Gateway',
    'Vivanta',
    'Ginger',
    'Tree of Life',
    'Ama',
    'Qmin',
    'Soulinaire',
    'Taj Sats'
  ];

  return (
    <footer className="bg-[#1A1A1A] text-neutral-300 pt-16 pb-12 border-t border-[#C5A059]/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-neutral-800">
          {/* Brand & Narrative */}
          <div className="lg:col-span-5 space-y-4">
            <h3 className="font-serif text-2xl sm:text-3xl font-bold tracking-wider text-white uppercase">
              The Taj Mahal Palace
            </h3>
            <p className="text-xs uppercase tracking-[0.2em] text-[#C5A059]">
              Apollo Bunder · Colaba, Mumbai, Maharashtra
            </p>
            <p className="text-xs sm:text-sm text-neutral-400 font-light leading-relaxed max-w-md">
              India’s premier luxury landmark overlooking the Arabian Sea and Gateway of India. A grand sanctuary where timeless heritage meets world-class luxury since 1903.
            </p>
          </div>

          {/* Quick Links */}
          <div className="lg:col-span-3 space-y-3">
            <p className="text-xs uppercase tracking-widest text-white font-semibold mb-2">
              Explore Palace
            </p>
            <ul className="space-y-2 text-xs sm:text-sm">
              <li>
                <a href="#suites" className="hover:text-[#C5A059] transition-colors">
                  Suites &amp; Heritage Rooms
                </a>
              </li>
              <li>
                <a href="#packages" className="hover:text-[#C5A059] transition-colors">
                  Experiential Packages
                </a>
              </li>
              <li>
                <a href="#dining" className="hover:text-[#C5A059] transition-colors">
                  Fine Dining &amp; Wasabi
                </a>
              </li>
              <li>
                <a href="#facilities" className="hover:text-[#C5A059] transition-colors">
                  Jiva Spa &amp; Courtyard Pool
                </a>
              </li>
              <li>
                <a href="#testimonials" className="hover:text-[#C5A059] transition-colors">
                  Verified Guest Reviews
                </a>
              </li>
              <li>
                <a href="#location" className="hover:text-[#C5A059] transition-colors">
                  Location &amp; Directions
                </a>
              </li>
              <li>
                <a href="#booking" className="hover:text-[#C5A059] transition-colors">
                  Direct Booking Guarantee
                </a>
              </li>
            </ul>
          </div>

          {/* Verified Contact Details Repetition */}
          <div className="lg:col-span-4 space-y-3 text-xs sm:text-sm">
            <p className="text-xs uppercase tracking-widest text-white font-semibold mb-2">
              Concierge Contact
            </p>
            <div className="flex items-start gap-3 text-neutral-300">
              <MapPin className="w-4 h-4 text-[#C5A059] shrink-0 mt-0.5" />
              <span>{HOTEL_INFO.address}</span>
            </div>
            <div className="flex items-center gap-3 text-neutral-300">
              <Phone className="w-4 h-4 text-[#C5A059] shrink-0" />
              <a href={`tel:${HOTEL_INFO.phoneClean}`} className="hover:text-[#C5A059] transition-colors">
                {HOTEL_INFO.phone} (Reservations)
              </a>
            </div>
            <div className="flex items-center gap-3 text-neutral-300">
              <Mail className="w-4 h-4 text-[#C5A059] shrink-0" />
              <a href={`mailto:${HOTEL_INFO.email}`} className="hover:text-[#C5A059] transition-colors">
                {HOTEL_INFO.email}
              </a>
            </div>
            <div className="flex items-center gap-3 text-neutral-300">
              <Globe className="w-4 h-4 text-[#C5A059] shrink-0" />
              <span>Taj Hotels, Resorts and Palaces</span>
            </div>
          </div>
        </div>

        {/* "Our Brands" Floating Loop in the Footer */}
        <div className="py-8 border-b border-neutral-800/80 overflow-hidden" aria-label="Our Brands floating loop showcase">
          <div className="flex items-center justify-between gap-4 mb-4">
            <div className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-[#C5A059]" />
              <p className="text-xs uppercase tracking-[0.25em] text-[#C5A059] font-semibold">
                Our Brands
              </p>
            </div>
            <span className="text-[11px] text-neutral-500 uppercase tracking-wider font-light hidden sm:inline">
              IHCL Hospitality Portfolio &amp; Select Alliances
            </span>
          </div>

          {/* Continuous Floating Horizontal Marquee Loop */}
          <div className="relative overflow-hidden select-none pause-hover py-2">
            <div className="animate-marquee-left flex items-center gap-8 text-sm sm:text-base text-neutral-300 font-serif tracking-wider">
              {/* Loop Sequence 1 */}
              {brands.map((brand, idx) => (
                <span key={`b1-${idx}`} className="flex items-center gap-8 whitespace-nowrap">
                  <span className="hover:text-white hover:text-[#E8D3A2] transition-colors cursor-default">
                    {brand}
                  </span>
                  <span aria-hidden="true" className="text-[#C5A059] font-sans text-xs">·</span>
                </span>
              ))}

              {/* Loop Sequence 2 (for seamless infinite loop) */}
              {brands.map((brand, idx) => (
                <span key={`b2-${idx}`} className="flex items-center gap-8 whitespace-nowrap">
                  <span className="hover:text-white hover:text-[#E8D3A2] transition-colors cursor-default">
                    {brand}
                  </span>
                  <span aria-hidden="true" className="text-[#C5A059] font-sans text-xs">·</span>
                </span>
              ))}

              {/* Loop Sequence 3 */}
              {brands.map((brand, idx) => (
                <span key={`b3-${idx}`} className="flex items-center gap-8 whitespace-nowrap">
                  <span className="hover:text-white hover:text-[#E8D3A2] transition-colors cursor-default">
                    {brand}
                  </span>
                  <span aria-hidden="true" className="text-[#C5A059] font-sans text-xs">·</span>
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Bar: Copyright & Accessibility Notice */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-500">
          <p>© 2026 The Taj Mahal Palace, Mumbai. All rights reserved.</p>

          <div className="flex items-center gap-6">
            <span className="text-neutral-500">WCAG 2.1 AA Compliant</span>
            <button
              onClick={scrollToTop}
              className="flex items-center gap-1.5 text-neutral-400 hover:text-white transition-colors"
              aria-label="Back to top"
            >
              <span>Back to Top</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
