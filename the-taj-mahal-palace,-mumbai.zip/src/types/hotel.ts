export type Currency = 'INR' | 'USD' | 'EUR' | 'GBP';

export interface Room {
  id: string;
  name: string;
  category: 'Luxury Room (Sea View)' | 'Taj Club Room' | 'Executive Suite' | 'Grand Presidential Suite';
  tagline: string;
  specs: {
    bed: string;
    capacity: string;
    area: string;
    view: string;
  };
  features: string[];
  pricePerNightINR: number;
  image: string;
  description: string;
  availabilitySignal: {
    status: 'low-inventory' | 'high-demand' | 'limited';
    text: string;
  };
}

export interface Dish {
  id: string;
  name: string;
  tagline: string;
  cuisineTab: 'indian' | 'international';
  restaurant: 'Shamiana' | 'Wasabi by Morimoto' | 'Golden Dragon' | 'Sea Lounge' | 'Harbour Bar';
  description: string;
  image: string;
  priceINR: number;
  dietary: 'Vegetarian' | 'Non-Vegetarian' | 'Seafood' | 'Dessert';
  tags: string[];
  chefNote?: string;
}

export interface Amenity {
  id: string;
  title: string;
  tagline: string;
  description: string;
  iconName: string;
  hours?: string;
}

export interface Testimonial {
  id: string;
  quote: string;
  author: string;
  stayDetail: string;
  rating: number;
}

export interface CategorizedTestimonial extends Testimonial {
  category: 'suites' | 'dining' | 'celebrations';
}

export interface ExperientialPackage {
  id: string;
  title: string;
  subtitle: string;
  tagline: string;
  duration: string;
  priceINR: number;
  image: string;
  highlights: string[];
  description: string;
  badge: string;
}

export interface AwardItem {
  id: string;
  year: string;
  organization: string;
  title: string;
  category: string;
  badge: string;
}

export interface FAQItem {
  id: string;
  category: 'Check-in & Stays' | 'Dining & Dress Code' | 'Airport & Location' | 'Policies & Concierge';
  question: string;
  answer: string;
}

export interface ReservationData {
  id: string;
  fullName: string;
  phone: string;
  email: string;
  checkIn: string;
  checkOut: string;
  adults: number;
  children: number;
  suitePreference: string;
  specialRequests: string;
  estimatedTotalINR: number;
  currency: Currency;
  estimatedFormattedTotal: string;
  submittedAt: string;
}
