import React, { useState, useEffect } from 'react';
import { ROOMS, HOTEL_INFO, formatCurrency } from '../data/hotelData';
import { ReservationData, Currency } from '../types/hotel';
import { Calendar, Users, Hotel, User, Phone, Mail, Sparkles, Send, ShieldCheck, Check } from 'lucide-react';

interface BookingSectionProps {
  preselectedSuite?: string;
  preselectedSpecialRequest?: string;
  currency?: Currency;
  onReservationSubmitted: (data: ReservationData) => void;
}

export const BookingSection: React.FC<BookingSectionProps> = ({
  preselectedSuite,
  preselectedSpecialRequest,
  currency = 'INR',
  onReservationSubmitted
}) => {
  // Helper to format ISO date YYYY-MM-DD
  const today = new Date().toISOString().split('T')[0];
  const tomorrow = new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0];

  const [fullName, setFullName] = useState('');
  const [dialCode, setDialCode] = useState('+91');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [checkIn, setCheckIn] = useState(today);
  const [checkOut, setCheckOut] = useState(tomorrow);
  const [adults, setAdults] = useState(2);
  const [children, setChildren] = useState(0);
  const [suitePreference, setSuitePreference] = useState(preselectedSuite || ROOMS[0].name);
  const [specialRequests, setSpecialRequests] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // Synchronize when preselectedSuite changes
  useEffect(() => {
    if (preselectedSuite) {
      setSuitePreference(preselectedSuite);
    }
  }, [preselectedSuite]);

  useEffect(() => {
    if (preselectedSpecialRequest) {
      setSpecialRequests((prev) =>
        prev ? `${prev}\n• ${preselectedSpecialRequest}` : `• ${preselectedSpecialRequest}`
      );
    }
  }, [preselectedSpecialRequest]);

  // Compute stay duration in nights
  const calculateNights = () => {
    const start = new Date(checkIn);
    const end = new Date(checkOut);
    const diff = (end.getTime() - start.getTime()) / (1000 * 3600 * 24);
    return diff > 0 ? Math.round(diff) : 1;
  };

  const nights = calculateNights();

  // Selected room details
  const selectedRoomObj = ROOMS.find((r) => r.name === suitePreference) || ROOMS[0];
  const estimatedSubtotalINR = selectedRoomObj.pricePerNightINR * nights;
  const formattedSubtotal = formatCurrency(estimatedSubtotalINR, currency);
  const formattedNightly = formatCurrency(selectedRoomObj.pricePerNightINR, currency);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!fullName.trim()) {
      setErrorMsg('Please enter your full name.');
      return;
    }
    if (!phone.trim()) {
      setErrorMsg('Please provide a valid contact phone number.');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      setErrorMsg('Please enter a valid email address.');
      return;
    }
    if (new Date(checkOut) <= new Date(checkIn)) {
      setErrorMsg('Check-out date must be after check-in date.');
      return;
    }

    const randomSuffix = Math.floor(10000 + Math.random() * 90000);
    const newReservation: ReservationData = {
      id: `TAJ-MUM-${randomSuffix}`,
      fullName: fullName.trim(),
      phone: `${dialCode} ${phone.trim()}`,
      email: email.trim(),
      checkIn,
      checkOut,
      adults,
      children,
      suitePreference,
      specialRequests: specialRequests.trim(),
      estimatedTotalINR: estimatedSubtotalINR,
      currency,
      estimatedFormattedTotal: formattedSubtotal,
      submittedAt: new Date().toISOString()
    };

    onReservationSubmitted(newReservation);
  };

  return (
    <section id="booking" className="py-24 bg-[#FAF9F6] border-b border-[#E8E6DF] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <p className="text-xs uppercase tracking-[0.25em] text-[#C5A059] font-semibold mb-2">
            Direct Palace Reservations
          </p>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-[#1A1A1A] leading-tight text-balance">
            Reserve Your Stately Experience
          </h2>
          <div className="w-16 h-0.5 bg-[#C5A059] mx-auto mt-4 mb-4" />
          <p className="text-neutral-600 text-sm sm:text-base font-light">
            Book directly with the palace to unlock complimentary butler coordination, flexible cancellation privileges, and prioritized Arabian Sea room placement.
          </p>
        </div>

        {/* 2-Column Booking Form & Reservation Estimation */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          {/* Left Column: Form Fields */}
          <div className="lg:col-span-8 bg-white border border-[#E5E2D9] rounded-sm p-6 sm:p-10 shadow-xs">
            {errorMsg && (
              <div className="mb-6 p-4 bg-red-50 border-l-4 border-red-500 text-red-700 text-xs sm:text-sm font-medium">
                {errorMsg}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Row 1: Guest Personal Info */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="fullName" className="block text-xs uppercase tracking-wider font-semibold text-neutral-700 mb-2">
                    Full Name <span className="text-[#C5A059]">*</span>
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      id="fullName"
                      type="text"
                      required
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="e.g. Lord Charles Sterling"
                      className="w-full pl-10 pr-4 py-3 bg-[#FAF9F6] border border-[#DCD9D0] rounded-sm text-sm text-[#1A1A1A] placeholder-neutral-400 focus:outline-none focus:border-[#C5A059] focus-visible:ring-2 focus-visible:ring-[#C5A059] transition-all"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="email" className="block text-xs uppercase tracking-wider font-semibold text-neutral-700 mb-2">
                    Email Address <span className="text-[#C5A059]">*</span>
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      id="email"
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="guest@luxury.com"
                      className="w-full pl-10 pr-4 py-3 bg-[#FAF9F6] border border-[#DCD9D0] rounded-sm text-sm text-[#1A1A1A] placeholder-neutral-400 focus:outline-none focus:border-[#C5A059] focus-visible:ring-2 focus-visible:ring-[#C5A059] transition-all"
                    />
                  </div>
                </div>
              </div>

              {/* Row 2: Phone with Dial Code */}
              <div>
                <label htmlFor="phone" className="block text-xs uppercase tracking-wider font-semibold text-neutral-700 mb-2">
                  Phone Number <span className="text-[#C5A059]">*</span>
                </label>
                <div className="grid grid-cols-12 gap-3">
                  <div className="col-span-4 sm:col-span-3">
                    <select
                      value={dialCode}
                      onChange={(e) => setDialCode(e.target.value)}
                      className="w-full px-3 py-3 bg-[#FAF9F6] border border-[#DCD9D0] rounded-sm text-sm text-[#1A1A1A] focus:outline-none focus:border-[#C5A059] focus-visible:ring-2 focus-visible:ring-[#C5A059] transition-all"
                    >
                      <option value="+91">+91 (India)</option>
                      <option value="+1">+1 (USA/CA)</option>
                      <option value="+44">+44 (UK)</option>
                      <option value="+971">+971 (UAE)</option>
                      <option value="+65">+65 (SG)</option>
                      <option value="+49">+49 (DE)</option>
                      <option value="+33">+33 (FR)</option>
                      <option value="+61">+61 (AU)</option>
                    </select>
                  </div>
                  <div className="col-span-8 sm:col-span-9 relative">
                    <Phone className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      id="phone"
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="98765 43210"
                      className="w-full pl-10 pr-4 py-3 bg-[#FAF9F6] border border-[#DCD9D0] rounded-sm text-sm text-[#1A1A1A] placeholder-neutral-400 focus:outline-none focus:border-[#C5A059] focus-visible:ring-2 focus-visible:ring-[#C5A059] transition-all"
                    />
                  </div>
                </div>
              </div>

              {/* Row 3: Check-in & Check-out Dates */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="checkIn" className="block text-xs uppercase tracking-wider font-semibold text-neutral-700 mb-2">
                    Check-in Date
                  </label>
                  <div className="relative">
                    <Calendar className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      id="checkIn"
                      type="date"
                      required
                      value={checkIn}
                      min={today}
                      onChange={(e) => setCheckIn(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 bg-[#FAF9F6] border border-[#DCD9D0] rounded-sm text-sm text-[#1A1A1A] focus:outline-none focus:border-[#C5A059] focus-visible:ring-2 focus-visible:ring-[#C5A059] transition-all"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="checkOut" className="block text-xs uppercase tracking-wider font-semibold text-neutral-700 mb-2">
                    Check-out Date
                  </label>
                  <div className="relative">
                    <Calendar className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      id="checkOut"
                      type="date"
                      required
                      value={checkOut}
                      min={checkIn || today}
                      onChange={(e) => setCheckOut(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 bg-[#FAF9F6] border border-[#DCD9D0] rounded-sm text-sm text-[#1A1A1A] focus:outline-none focus:border-[#C5A059] focus-visible:ring-2 focus-visible:ring-[#C5A059] transition-all"
                    />
                  </div>
                </div>
              </div>

              {/* Row 4: Suite Preference & Occupancy */}
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-6">
                <div className="sm:col-span-6">
                  <label htmlFor="suitePreference" className="block text-xs uppercase tracking-wider font-semibold text-neutral-700 mb-2">
                    Suite / Room Preference
                  </label>
                  <div className="relative">
                    <Hotel className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <select
                      id="suitePreference"
                      value={suitePreference}
                      onChange={(e) => setSuitePreference(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 bg-[#FAF9F6] border border-[#DCD9D0] rounded-sm text-sm text-[#1A1A1A] focus:outline-none focus:border-[#C5A059] focus-visible:ring-2 focus-visible:ring-[#C5A059] transition-all"
                    >
                      {ROOMS.map((room) => (
                        <option key={room.id} value={room.name}>
                          {room.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="sm:col-span-3">
                  <label htmlFor="adults" className="block text-xs uppercase tracking-wider font-semibold text-neutral-700 mb-2">
                    Adults
                  </label>
                  <div className="relative">
                    <Users className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <select
                      id="adults"
                      value={adults}
                      onChange={(e) => setAdults(Number(e.target.value))}
                      className="w-full pl-10 pr-4 py-3 bg-[#FAF9F6] border border-[#DCD9D0] rounded-sm text-sm text-[#1A1A1A] focus:outline-none focus:border-[#C5A059] focus-visible:ring-2 focus-visible:ring-[#C5A059] transition-all"
                    >
                      {[1, 2, 3, 4, 5, 6].map((num) => (
                        <option key={num} value={num}>
                          {num} {num === 1 ? 'Adult' : 'Adults'}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="sm:col-span-3">
                  <label htmlFor="children" className="block text-xs uppercase tracking-wider font-semibold text-neutral-700 mb-2">
                    Children
                  </label>
                  <select
                    id="children"
                    value={children}
                    onChange={(e) => setChildren(Number(e.target.value))}
                    className="w-full px-4 py-3 bg-[#FAF9F6] border border-[#DCD9D0] rounded-sm text-sm text-[#1A1A1A] focus:outline-none focus:border-[#C5A059] focus-visible:ring-2 focus-visible:ring-[#C5A059] transition-all"
                  >
                    {[0, 1, 2, 3].map((num) => (
                      <option key={num} value={num}>
                        {num} {num === 1 ? 'Child' : 'Children'}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Row 5: Special Requests */}
              <div>
                <label htmlFor="specialRequests" className="block text-xs uppercase tracking-wider font-semibold text-neutral-700 mb-2">
                  Special Requests &amp; Bespoke Arrangements
                </label>
                <textarea
                  id="specialRequests"
                  rows={3}
                  value={specialRequests}
                  onChange={(e) => setSpecialRequests(e.target.value)}
                  placeholder="Airport limousine pickup, anniversary flower setup, dietary preferences, extra pillows..."
                  className="w-full px-4 py-3 bg-[#FAF9F6] border border-[#DCD9D0] rounded-sm text-sm text-[#1A1A1A] placeholder-neutral-400 focus:outline-none focus:border-[#C5A059] focus-visible:ring-2 focus-visible:ring-[#C5A059] transition-all resize-none"
                />
              </div>

              {/* Submit CTA */}
              <button
                type="submit"
                className="w-full py-4 bg-[#C5A059] hover:bg-[#a7823b] text-white font-semibold text-sm uppercase tracking-widest rounded-sm shadow-md transition-all duration-200 flex items-center justify-center gap-2 transform active:scale-[0.99] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059] focus-visible:ring-offset-2"
              >
                <Send className="w-4 h-4" />
                <span>Submit Reservation Request</span>
              </button>
            </form>
          </div>

          {/* Right Column: Live Booking Estimation & Palace Guarantee */}
          <div className="lg:col-span-4 space-y-6">
            {/* Live Pricing Estimation Card */}
            <div className="bg-[#FAF9F6] border border-[#C5A059]/40 rounded-sm p-6 shadow-xs">
              <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-[#C5A059] font-semibold mb-3">
                <Sparkles className="w-4 h-4 text-[#C5A059]" />
                <span>Live Estimate</span>
              </div>

              <h3 className="font-serif text-2xl font-bold text-[#1A1A1A] mb-4">
                {selectedRoomObj.name}
              </h3>

              <div className="space-y-3 text-xs sm:text-sm text-neutral-600 pb-4 border-b border-[#E8E6DF]">
                <div className="flex justify-between">
                  <span>Duration:</span>
                  <span className="font-medium text-[#1A1A1A]">{nights} {nights === 1 ? 'Night' : 'Nights'}</span>
                </div>
                <div className="flex justify-between">
                  <span>Nightly Rate:</span>
                  <span className="font-medium text-[#1A1A1A] tabular-nums">
                    {formattedNightly}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Guests:</span>
                  <span className="font-medium text-[#1A1A1A]">{adults} Adults {children > 0 ? `, ${children} Children` : ''}</span>
                </div>
              </div>

              <div className="pt-4 space-y-2">
                <div className="flex justify-between items-baseline">
                  <span className="text-xs uppercase tracking-wider text-neutral-500 font-semibold">Estimated Total:</span>
                  <div className="text-right">
                    <p className="font-serif text-2xl font-bold text-[#1A1A1A] tabular-nums">
                      {formattedSubtotal}
                    </p>
                    <p className="text-[11px] text-neutral-500 font-mono">
                      Currency: {currency}
                    </p>
                  </div>
                </div>
                <p className="text-[11px] text-neutral-400 italic">
                  *Taxes, luxury GST, and butler service inclusions finalized at booking confirmation.
                </p>
              </div>
            </div>

            {/* Direct Booking Palace Privileges */}
            <div className="bg-white border border-[#E5E2D9] rounded-sm p-6 space-y-3 shadow-2xs">
              <p className="text-xs uppercase tracking-wider font-semibold text-[#1A1A1A]">
                Taj Direct Booking Privileges
              </p>
              <ul className="space-y-2 text-xs text-neutral-700">
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-[#C5A059] shrink-0" />
                  <span>Best Available Rate Guarantee</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-[#C5A059] shrink-0" />
                  <span>Complimentary High-Speed Wi-Fi</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-[#C5A059] shrink-0" />
                  <span>24/7 Dedicated Palace Butler Coordination</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-[#C5A059] shrink-0" />
                  <span>Priority Table Placement at Wasabi &amp; Shamiana</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
