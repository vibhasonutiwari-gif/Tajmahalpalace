import React, { useState } from 'react';
import { EXPERIENTIAL_PACKAGES, formatCurrency } from '../data/hotelData';
import { ExperientialPackage, Currency } from '../types/hotel';
import { Check, Sparkles, Clock, ArrowRight } from 'lucide-react';

interface ExperientialPackagesProps {
  onSelectPackage: (pkg: ExperientialPackage) => void;
  currency?: Currency;
  onCurrencyChange?: (currency: Currency) => void;
}

export const ExperientialPackages: React.FC<ExperientialPackagesProps> = ({
  onSelectPackage,
  currency = 'INR',
  onCurrencyChange,
}) => {
  const [localCurrency, setLocalCurrency] = useState<Currency>(currency);

  const activeCurrency = onCurrencyChange ? currency : localCurrency;
  const handleCurrencyToggle = (c: Currency) => {
    if (onCurrencyChange) {
      onCurrencyChange(c);
    } else {
      setLocalCurrency(c);
    }
  };

  const currencies: Currency[] = ['INR', 'USD', 'EUR', 'GBP'];

  return (
    <section id="packages" className="py-24 bg-[#FAF9F6] border-b border-[#E8E6DF]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <p className="text-xs uppercase tracking-[0.25em] text-[#8C651E] font-semibold mb-2">
              Curated Palace Immersions
            </p>
            <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-[#1A1A1A] text-balance">
              Experiential Packages &amp; Stays
            </h2>
            <div className="w-16 h-0.5 bg-[#C5A059] mt-4 mb-3" />
            <p className="text-neutral-700 text-sm sm:text-base max-w-xl font-light">
              Crafted journeys celebrating century-old heritage, master gastronomy at Wasabi by Morimoto, and transformative Ayurvedic healing at Jiva Spa.
            </p>
          </div>

          {/* Currency Toggle */}
          <div className="flex items-center gap-1.5 p-1 bg-white rounded-md border border-[#E0DDD5] self-start md:self-end shadow-xs" role="group" aria-label="Select package currency">
            <span className="text-xs text-neutral-600 pl-2 pr-1 font-medium hidden sm:inline">Currency:</span>
            {currencies.map((curr) => (
              <button
                key={curr}
                onClick={() => handleCurrencyToggle(curr)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-xs transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059] focus-visible:ring-offset-2 ${
                  activeCurrency === curr
                    ? 'bg-[#C5A059] text-white shadow-xs'
                    : 'text-neutral-700 hover:text-black hover:bg-[#FAF9F6]'
                }`}
                aria-pressed={activeCurrency === curr}
                aria-label={`Display package prices in ${curr}`}
              >
                {curr === 'INR' ? '₹ INR' : curr === 'USD' ? '$ USD' : curr === 'EUR' ? '€ EUR' : '£ GBP'}
              </button>
            ))}
          </div>
        </div>

        {/* 3 Packages Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {EXPERIENTIAL_PACKAGES.map((pkg) => {
            const formattedPrice = formatCurrency(pkg.priceINR, activeCurrency);

            return (
              <div
                key={pkg.id}
                className="bg-white border border-[#E8E6DF] rounded-sm overflow-hidden flex flex-col justify-between hover:border-[#C5A059] hover:shadow-xl transition-all duration-300 group"
              >
                <div>
                  {/* Package Media Banner with native lazy-loading and verified photography */}
                  <div className="relative h-60 overflow-hidden bg-neutral-900">
                    <img
                      src={pkg.image}
                      alt={`${pkg.title} at The Taj Mahal Palace, Mumbai`}
                      width="600"
                      height="400"
                      loading="lazy"
                      decoding="async"
                      className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />

                    {/* Badge */}
                    <div className="absolute top-4 left-4">
                      <span className="px-3 py-1 bg-[#C5A059] text-white text-[11px] uppercase tracking-wider font-semibold rounded-xs shadow-md">
                        {pkg.badge}
                      </span>
                    </div>

                    {/* Bottom Duration & Title */}
                    <div className="absolute bottom-4 left-4 right-4 text-white">
                      <div className="flex items-center gap-1.5 text-xs text-[#E8D3A2] font-medium mb-1">
                        <Clock className="w-3.5 h-3.5 text-[#C5A059]" />
                        <span>{pkg.duration}</span>
                      </div>
                      <h3 className="font-serif text-2xl font-bold">
                        {pkg.title}
                      </h3>
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-6">
                    <p className="text-xs uppercase tracking-wider font-semibold text-[#8C651E] mb-2">
                      {pkg.subtitle}
                    </p>

                    <p className="text-xs sm:text-sm text-neutral-700 font-light leading-relaxed mb-6">
                      {pkg.description}
                    </p>

                    {/* Curated Inclusions */}
                    <div className="space-y-2.5 pt-4 border-t border-[#EFECE6]">
                      <p className="text-[11px] uppercase tracking-wider font-semibold text-neutral-500">
                        Curated Privileges Included
                      </p>
                      <ul className="space-y-2">
                        {pkg.highlights.map((h, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-xs text-neutral-800 leading-snug">
                            <Check className="w-3.5 h-3.5 text-[#C5A059] shrink-0 mt-0.5" />
                            <span>{h}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Card Footer with Price and Book CTA */}
                <div className="p-6 bg-[#FAF9F6] border-t border-[#E8E6DF] flex items-center justify-between gap-4">
                  <div>
                    <span className="text-[11px] uppercase tracking-wider text-neutral-500 font-medium">Starting from</span>
                    <p className="font-serif text-xl sm:text-2xl font-bold text-[#1A1A1A] tabular-nums">
                      {formattedPrice}
                    </p>
                  </div>

                  <button
                    onClick={() => onSelectPackage(pkg)}
                    className="px-5 py-2.5 bg-[#1A1A1A] hover:bg-[#C5A059] text-white text-xs font-semibold uppercase tracking-wider rounded-sm transition-colors flex items-center gap-1.5 shadow-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059] focus-visible:ring-offset-2"
                    aria-label={`Book experience package: ${pkg.title}`}
                  >
                    <span>Reserve Package</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
