import React, { useState } from 'react';
import { TESTIMONIALS_DATA } from '../data/hotelData';
import { CategorizedTestimonial } from '../types/hotel';
import { Star, CheckCircle, Quote, Sparkles, Building2, Utensils, Award } from 'lucide-react';

export const TestimonialsSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'all' | 'suites' | 'dining' | 'celebrations'>('all');

  const filteredReviews = TESTIMONIALS_DATA.filter((item) => {
    if (activeTab === 'all') return true;
    return item.category === activeTab;
  });

  const tabs = [
    { id: 'all', label: 'All Impressions (9)', icon: Sparkles },
    { id: 'suites', label: 'Suites & Stays (5)', icon: Building2 },
    { id: 'dining', label: 'Fine Dining & Wasabi (2)', icon: Utensils },
    { id: 'celebrations', label: 'Galas & Celebrations (2)', icon: Award }
  ];

  return (
    <section id="testimonials" className="py-24 bg-[#FAF9F6] border-b border-[#E8E6DF]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <p className="text-xs uppercase tracking-[0.25em] text-[#8C651E] font-semibold mb-2">
            Cherished by Generations of Discerning Travelers
          </p>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl font-bold text-[#1A1A1A] leading-tight text-balance">
            Guest Impressions &amp; Verified Royal Reviews
          </h2>
          <div className="w-16 h-0.5 bg-[#C5A059] mx-auto mt-4 mb-4" />
          <p className="text-neutral-700 text-sm sm:text-base font-light">
            Over a century of welcoming royalty, diplomats, and cultural luminaries to Mumbai’s Arabian Sea shores.
          </p>
        </div>

        {/* Choice of Tabs */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-12" role="tablist">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                role="tab"
                aria-selected={isActive}
                aria-controls="reviews-grid"
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 sm:px-5 py-2.5 text-xs sm:text-sm font-semibold rounded-sm transition-all duration-200 flex items-center gap-2 border focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C5A059] focus-visible:ring-offset-2 ${
                  isActive
                    ? 'bg-[#1A1A1A] text-white border-[#1A1A1A] shadow-md'
                    : 'bg-white text-neutral-700 border-[#E0DDD5] hover:border-[#C5A059] hover:text-[#1A1A1A]'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#C5A059]' : 'text-neutral-500'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Polished, High-Contrast Testimonial Cards with Hover-Lift Animations */}
        <div id="reviews-grid" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {filteredReviews.map((review) => (
            <div
              key={review.id}
              className="bg-white border border-[#E5E2D9] p-7 rounded-sm shadow-sm hover:shadow-xl hover:border-[#C5A059] transition-all duration-300 transform hover:-translate-y-1.5 flex flex-col justify-between group"
            >
              <div>
                {/* Header: Rating & Verified Guest Badge */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-1 text-[#C5A059]" aria-label={`${review.rating} out of 5 stars`}>
                    {[...Array(review.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-[#C5A059]" />
                    ))}
                  </div>

                  <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-sm border border-emerald-200/60">
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                    Verified Guest
                  </span>
                </div>

                {/* Quote in Grand Serif with High Contrast */}
                <p className="font-serif text-base sm:text-lg text-[#1A1A1A] leading-relaxed italic mb-6">
                  "{review.quote}"
                </p>
              </div>

              {/* Author, Room Category, and Stay Duration */}
              <div className="pt-4 border-t border-[#EFECE6] flex items-center justify-between">
                <div>
                  <h4 className="font-serif font-bold text-base text-[#1A1A1A] group-hover:text-[#8C651E] transition-colors">
                    {review.author}
                  </h4>
                  <p className="text-xs font-semibold text-[#8C651E] mt-0.5">
                    {review.stayDetail}
                  </p>
                </div>

                <div className="w-8 h-8 rounded-full bg-[#FAF9F6] border border-[#E0DDD5] flex items-center justify-center text-[#C5A059] group-hover:bg-[#C5A059] group-hover:text-white transition-colors">
                  <Quote className="w-4 h-4" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
